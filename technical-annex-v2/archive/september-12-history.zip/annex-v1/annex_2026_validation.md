# 2026 annex validation

Date: 11 September 2026. Track: assessment technical annex, working SC14 update.

## Current update: corrected template and ten-year risk tables

This update supersedes the earlier five-year risk and scenario-4 validation records below. The original assessment files are preserved; new projection products are stored in `projection-10yr/`.

- **Model source: Pass.** `jjm.tpl` compiles with ADMB 13.2. Global MSY optimization and evaluation use `sel_msy`, default 15 completed years (2011–2025). Projection MSY optimization and scenario-4 application both use `sel_fut` (2023–2025 in these runs). The fleet allocation is applied once. MSY-based next-year OFL uses the same projection reference. Annual reference reporting restores global reference fields and natural mortality after its temporary calculations. `jjm2.tpl` is unchanged.
- **Replacement yield: Pass.** Stock-specific fleets, Baranov catch, Beverton–Holt recruitment and plus-group survival reproduce the consecutive-year condition B2028 = B2027 under the same trial F. All six model/component roots have absolute reported residuals below 0.001 kt. Precautionary catches are 1,104.7 kt (single), 895.5 kt (South) and 15.7 kt (Far North).
- **Controlled runs: Pass.** Four model configurations retain all saved fitted parameters exactly. Historical numbers at age, mortality, fishing mortality and annual reference tables are unchanged. Independent equilibrium optimization and all ten years of scenario-4 biomass/catch agree within report rounding. Six additional component/window checks confirm that global references are invariant to future selectivity; matching windows produce matching optima for these configurations.
- **Uncertainty: Pass.** Both precautionary runs extend through 2036 with newly computed Hessians and derived standard errors. Minimum Hessian eigenvalues are 0.04548856 (h1) and 0.02730115 (h2). All 180 projected biomass estimates and standard errors are finite, with positive biomass standard errors. Probabilities retain the fixed base annual-average BMSY thresholds and the conditional normal method.
- **Report scope.** Risk tables use years 2028, 2031 and 2036 (2, 5 and 10 years after 2026), with catches for 2027–2028. The reference diagram, equations and replacement explanations describe the corrected model. Earlier five-year projection figures are explicitly labelled as historical comparisons. No assessment refit or MSE simulation was performed.
- **Evidence.** `projection-10yr/manifest.json`, `model-validation.json`, `html-validation.json`, raw R reports, controls, parameter inputs, annual risk CSV and reference-value CSV. Browser interaction remains Not Tested; native HTML values, links and diagram layout are checked separately.

## Earlier validation history

The sections below document earlier revisions and their then-current outputs; their five-year probabilities and selectivity descriptions are superseded by the update above.

## Scope and provenance

Updated the SC13 annex to the current Model 1.06 assessment under both stock hypotheses, with benchmark/SCW17 chronology and this week's assessment/MSE work. The annex continues to use saved model and projection products. A subsequent scenario-4 source revision was validated with isolated fixed-parameter model executions, as documented below; no assessment refit, MSE simulation or replacement of saved projections was performed. Authoritative inputs and source-file hashes are in `annex_2026_sources.json`. The live JM wiki still requires agreed SC14 decision text; working results and proposed CMP sets retain that status.

The source uses existing JJM/Quarto report components, preserving the assessment/data/model/output boundaries. NOAA asar is not applicable to this SPRFMO annex. Provenance is recorded without migrating the model workflow.

## Checks

| Gate | Outcome | Evidence and limits |
|---|---|---|
| Development track | Pass | Working technical annex; workshop conclusions and formal management decisions distinguished. |
| Provenance | Pass | Model, projection and source-file identifiers/hashes recorded. Existing untracked jjm2 source is identified, rather than presumed committed. |
| Scientific reconciliation | Pass within scope | Current six-index structure; catch additions; 2020–2024 Offshore weight mean; fixed M and spawning timing; selectivity pathways; 15 status values independently checked against saved reports; terminal-year retrospective alignment. This is not independent model validation or SC adoption. |
| Consistency | Pass | Old SC13 current-advice statements and 2025 risk tables replaced with three 2026 risk tables in the results summary; current data-derived tables and conditional .ls projection figures supplied. Added the reference-point/projection diagram, equations and two native value tables; corrected the source alignment claim. Reference-point, MCMC and replacement-yield qualifications retained. |
| HTML render | Pass | Quarto 1.10.18; full document computation completed; final render contains no warnings or unresolved references. |
| Source and HTML structure | Pass | Bibliography keys/cross-reference targets present; 96 internal fragment links valid; no duplicate IDs or exposed code/console output. |
| Numerical tables | Pass | Status table matches all 15 displayed values from native model output. Three risk tables match all 144 displayed numeric/probability values across 18 scenario rows. Independent raw-report parsing verified 90 projection records and 450 values, including standard errors and normal-tail probabilities. |
| Images | Pass for presence | 50 rendered images, each with nonempty alt text; image resources available. Key metadata, summary, projection and corrected selectivity plots visually inspected as local PNGs. |
| External links | Pass for HTTP availability | 14 distinct public links returned HTTP 200. |
| Browser layout and interaction | Not Tested | Browser tool policy blocked the local-file preview; no alternate browser route attempted. HTML DOM/fragment checks and local figure inspection were completed. |
| Accessibility | Partial automated evidence | Document language, title, captions, alt presence and native tables checked. Screen-reader order, detailed table associations, all contrast/colour encoding, and complete manual review not tested; no Section 508 certification claimed. |
| DOCX/PDF | Not Tested | HTML rendered for this source update. Existing DOCX format remains configured; no new Word/PDF output supplied. |

## Material scientific qualifications

- Dynamic-BMSY annual-report support remains to be reconciled with the installed fixed_bmsy function; this annex's status table uses fixed mean annual BMSY for 2017–2026.
- The Far North replacement-yield zero is a failed-feasibility boundary result, not an attained replacement yield.
- The current ADNUTS outputs have mixing/ESS failures and remain exploratory.
- CMP discussion sets, risk tolerances and implementation arrangements await the relevant agreed decision records.
- Country-level catches are linked to SC14-JM01; the available current model fleet totals are tabulated. The prior country spreadsheet is absent from the checkout.

## Risk-table restoration

The results summary contains separate single-stock, southern-component and Far North risk tables. Six saved scenarios show biomass and the annual probability of exceeding fixed BMSY in 2027, 2029 and 2031, and catch in 2027 and 2028. The fixed BMSY thresholds match the base-model stock-status table. Probabilities use the existing JJM conditional normal approximation from ADMB estimates and standard errors; they exclude reference-point uncertainty and differ from MSE and MCMC probabilities. Values below 1% and above 99% retain tail labels. All saved projections use steepness 0.65; the single/southern recruitment period is 2001–2015, while Far North retains 1970–2016. The saved TAC scenario is labelled explicitly pending reconciliation with intended management catch.

Independent raw-report checks are recorded in `jmMSE26/output/annex-risk-table-2026/independent-risk-validation.json`; displayed-value and lightbox checks are in `risk-html-validation.json` in that directory. No model runs were performed.

## Reference-point diagram and equations

- Scientific source review: **Pass**. Annual reference points, fixed ten-year BMSY, scalar fifteen-year MSY calculation, and three-year projection selectivity are distinguished. Beverton–Holt, per-recruit, plus-group, mortality, biomass and catch equations checked against jjm.tpl.
- Numerical checks: **Pass**. Annual values are read from saved reports. Scalar MSY values are reconstructed from rounded model outputs and parameters using eight Newton steps. Six saved yield profiles match the fifteen-year evaluator. First-year scenario-4 reconstruction agrees with all six saved model/component outputs within 0.010 kt SSB and 0.002 kt catch.
- Output checks: **Pass within scope**. All 21 values in the two new tables match in both HTML documents (42 displayed values checked); six labelled equation blocks and the diagram resolve. Diagram PNG inspected and label spacing corrected; vector SVG/PDF generated from the same drawing source. The full annex retains all 15 stock-status and 144 risk-table values.
- Provenance qualification: base run script invokes jjm2 and base reports contain its replacement-status fields. Current jjm2 source changes the no-year evaluator to sel_fut while retaining the sel_msy optimizer; saved profiles match the fifteen-year evaluator. The document explicitly avoids attributing saved profiles to that current edit.
- Accessibility: diagram alternative text, adjacent equations, native tables and source descriptions supplied. Browser interaction and screen-reader behaviour remain **Not Tested**.

The standalone companion is `reference_points.html`, with editable `reference_points.qmd` and `annex_reference_points.qmd`. Diagram files are `reference-points-diagram.png`, `.svg` and `.pdf`; drawing source is `reference_points_diagram.R`. `reference_points_extract.py`, `reference_points_values.json` and `reference_points_numerical_validation.json` retain the calculation record. The diagram source is a snapshot of the displayed values; if model outputs change, update it from the regenerated numerical record and rerender both documents.

## Supplied 2022 Annex K guidance

- Source gate: **Pass**. Both pages of the supplied PDF were extracted and visually read. The document identifies a proposed rule adjusted at SCW14; subsequent adoption is not inferred. A byte-identical local source copy is linked from both HTML outputs.
- Scientific gate: **Pass within documentation scope**. Independent review verified the coming-year SSB input; historical-minimum dynamic Blim formula; exact 80%/100% biomass boundaries; trial F and replacement-catch comparisons; closure precedence; and 15% TAC limits in the upper two bands. Equality and stability-conflict handling remain explicit unresolved implementation choices.
- Implementation mapping: **Pass**. Saved projection scenarios and fixed-BMSY exceedance probabilities remain distinct from the full HCR. The jjm2 replacement diagnostic's B2028 = B2026 target is distinguished from the proposal's consecutive-year B2028 = B2027 target for catch2027.
- Render and consistency: **Pass**. Both HTML documents render successfully, contain the four HCR rule rows and four labelled HCR equations, and match all six illustrative biomass-band values. The previous 15 status values, 144 risk values and 21 reference-point values remain verified. All 49 full-size figure targets are present.
- Visual/accessibility evidence: **Pass for inspected items**. New decision diagram PNG inspected; minimum-function notation corrected; no clipped or overlapping labels. Explicit alternative text, adjacent native table and equations are present. Browser interaction and screen-reader behaviour remain **Not Tested**.
- Scope: no model, control, assessment-data or projection output was changed; no operational TAC was computed. Numerical Blim is not invented without the matched historical and coming-year unfished series.

Files: `annex_hcr_2022.qmd`, `annex-k-decision-diagram.png` / `.svg`, editable `annex_k_diagram.R`, supplied source `HCR_2022_Annex_K.pdf`, and `annex_k_validation.json`. The existing `reference_points.html` companion includes this guidance after the model calculation diagram and equations.

## Simple SRR convention graphic

- Scientific check: **Pass**. The graphic distinguishes the long-term base SRR used for BMSY from the conventional precautionary SRR used for projections. The graphic is specific to the 1-stock hypothesis: recruitment fitting periods are 2000–2023 and 2001–2015, with steepness 0.65 in both. Direct extraction from saved h1 base and precautionary reports confirms mean annual BMSY for 2017–2026 of 6.869 and 6.041 Mt. The graphic explicitly retains 6.869 Mt as the target used to evaluate projected biomass; 6.041 Mt is shown as the comparable precautionary-run equilibrium estimate. The annual 2026 and reconstructed scalar reference points remain distinguished in the detailed text. The separate 2-stock section is preserved.
- Render/visual checks: **Pass**. PNG reviewed for legibility and spacing; SVG and editable R drawing source supplied. Both HTML outputs contain the embedded graphic, descriptive alternative text and exact period/steepness qualifications. The preceding model-calculation and Annex K diagrams remain present. All 50 full-size figure links resolve, all internal fragments resolve, and the reference-point tables remain numerically verified.
- Scope: explanatory graphic with verified numerical estimates; no model assumptions or outputs changed. Browser interaction and screen-reader behaviour remain **Not Tested**.

Files: `srr-convention-diagram.png`, `srr-convention-diagram.svg`, `srr_convention_diagram.R` and `srr_convention_validation.json`. The graphic opens Management advice and decision status in the annex and remains at the beginning of the companion. Its shared source is annex_srr_convention.qmd.

## Management presentation and probability headings

- Structure: **Pass**. The existing `management-advice-and-decision-status` anchor is preserved. The SRR graphic occurs once in the annex and precedes the separate `1-stock` and `2-stock` subsections. The companion retains its introductory graphic through a shared source include.
- Content: **Pass within scope**. The subsections retain the respective base/projection SRR periods, fixed biomass targets, risk-table references, coming-year HCR input and replacement-yield qualifications. The Far North exception is explicit.
- Risk table headings: **Pass**. Columns 3, 5 and 7 in all three risk tables read P(B > B_msy) in 2027, 2029 and 2031, with msy formatted as a subscript. All nine headers checked in native HTML; the captions define probabilities as whole percentages. All 144 data values remain unchanged and verified.
- Render: **Pass**. The annex and companion render without unresolved references; all 50 full-size figures are available. Existing native reference-point tables and status values remain verified. Browser layout/interaction remains **Not Tested**.

Detailed checks: `annex_management_validation.json`. Changes are limited to report structure, explanatory text and table headings; model inputs and outputs are unchanged.

## Risk provenance and scenario-4 source revision

- Risk calculation: **Pass**. The 1-stock projection means and ADMB standard errors come from `h1_1.06.ls.ctl` and its saved report; fixed BMSY comes from the 2017–2026 mean of the base `h1_1.06.ctl` report. The 2027 scenario-4 example gives 32.0894%, displayed as 32%, using B = 6377.68 kt, SE = 1056.21 kt and BMSY = 6869.029054 kt. BMSY uncertainty is excluded; these are annual normal approximations conditional on the selected model.
- Source change: **Pass**. `jjm.tpl` scenario 4 now applies `sel_msy * Fratio * Fmsy`, matching the scalar MSY selectivity. The same fishing mortality supplies survival, future spawning biomass and catch. Prior user edits were preserved; `jjm2.tpl` and its executable were untouched.
- Build and behavior: **Pass**. Both source versions compiled with ADMB 13.2. Six isolated executions with saved parameters, `-maxfn 0 -nohess`, covered h1 and h2 with `fut_sel` 3 and 0. All parameter values were unchanged exactly. Only `SSB_fut_4` and `Catch_fut_4` changed between source versions; all other report blocks were identical. Revised scenario 4 was invariant to `fut_sel` 0 versus 3. For h1 in 2027, central catch changed from 617.117 to 1097.900 kt and spawning biomass from 6377.68 to 6000.48 kt.
- Output status: **Saved results retained**. Updated projection probabilities require ADMB uncertainty calculations with the revised source. The no-Hessian checks do not provide these probabilities. Both HTML pages identify the displayed diagrams and numbers as saved outputs predating this source change. `SC14.R` currently invokes `jjm2`; using this revision requires the compiled `jjm` source.
- Document checks: **Pass within scope**. Both HTML pages render with the new qualifications. All 144 risk-table values, 15 status values and 42 displayed reference-table values remain verified; all 50 full-size figures resolve. Browser interaction remains **Not Tested**.

Evidence: `scenario4_selectivity_validation.json`, `risk_provenance_validation.json`, and the isolated commands, logs and reports in `jmMSE26/output/scenario4-sel-msy-2026`.

## Rebuild

From the JJM repository run `quarto render doc/annex/annex.qmd --to html --no-clean` with the existing jjmR environment. Paths are resolved from the source to `assessment/`; dates and assessment year are explicitly set to 2026. Quarto requires normal access to its user cache. Keep `annex_files/figure-html` beside the HTML for full-size lightbox images.

The rendered page embeds its images, while full-size lightbox links reference the figure directory. The delivered directory was restored byte-for-byte from the embedded PNGs after Quarto cleaned temporary resources. The resource directory was still cleaned with `--no-clean` in this environment; preserve or restore these resources when rebuilding. All 50 full-size image targets were checked.

## Scientific citation revision, 11 September 2026

- **Track: editorial revision of the technical annex.** Native JJM/Quarto sources and saved model products are retained; asar migration is not applicable.
- **References: Pass.** APA author-year citations replace direct literature links and source-file line citations. The main annex has 29 citation groups covering 19 works; the reference companion has four groups covering three works. Each citation resolves to the alphabetical reference list, with no uncited entries.
- **Metadata: Pass within scope.** Workshop/report numbers and corporate authors were checked against official SPRFMO document catalogues; named authors and titles were checked in original source documents. Unsigned working reports use title-first references. Draft, exploratory and proposal status are retained. DOI identifiers for the ADMB and von Bertalanffy papers were checked against publisher records.
- **Scientific consistency: Pass.** All table cells and figure images in both HTML documents match the pre-edit versions. The 144 displayed risk values, nine probability headings, 48 scalar reference values and 15 stock-status values remain verified.
- **Render and links: Pass.** Both HTML outputs render without citation warnings. All 50 figures retain alt text and the 47 model-plot lightbox files are present. Browser interaction and a full accessibility audit are Not Tested.
- Evidence: `citation_validation.json` and the staged checks in `jmMSE26/output/annex-citations-2026`.
