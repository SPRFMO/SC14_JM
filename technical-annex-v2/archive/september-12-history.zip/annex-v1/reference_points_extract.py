from pathlib import Path
import math,json,csv
ROOT=Path('/Users/jim/_mymods/sprfmo/jjm/assessment/results')
OUT=Path(__file__).resolve().parent
def read(p):
 d={};ln={};k=None
 for i,x in enumerate(p.read_text().splitlines(),1):
  if x.startswith('$'):k=x[1:].strip();d[k]=[];ln[k]=i
  elif k and x.strip():
   try:d[k].append([float(v) for v in x.split()])
   except:pass
 return d,ln
def par(p):
 d={};k=None
 for x in p.read_text().splitlines():
  if x.startswith('# '):k=x[2:].strip(':');d[k]=[]
  elif k:
   try:d[k]+=list(map(float,x.split()))
   except:pass
 return d
def maxim(fun,lo=.001,hi=5):
 g=(5**.5-1)/2;c=hi-g*(hi-lo);d=lo+g*(hi-lo)
 for _ in range(100):
  if fun(c)>fun(d):hi=d;d=c;c=hi-g*(hi-lo)
  else:lo=c;c=d;d=lo+g*(hi-lo)
 return (hi+lo)/2
records=[]
for model in ['h1_1.06','h2_1.06','h1_1.06.ls','h2_1.06.ls']:
 params=par(ROOT/(model+'.par'))
 for stock in ([1] if model.startswith('h1') else [1,2]):
  filename=f'{model}_{stock}_R.rep';d,ln=read(ROOT/filename)
  annual=next(v for v in d['msy_mt'] if v[0]==2026)
  fleets=[0,1,2,3] if model.startswith('h1') else ([0,1,3] if stock==1 else [2])
  fa={k:d[f'F_age_{k+1}'][-1][1:] for k in fleets}
  rat={k:sum(fa[k])/sum(sum(v) for v in fa.values()) for k in fleets}
  M=d['M'][0];wp=d['wt_a_pop'][0];mat=d['mature_a'][0];mature=[x*y for x,y in zip(wp,mat)]
  R0=math.exp(params[f'log_Rzero[{stock}]'][-1]);h=params[f'steepness[{stock}]'][-1];B0=annual[10]
  alpha=B0*(1-(h-.2)/(.8*h))/R0;beta=(5*h-1)/(4*h*R0)
  wf={k:d[f'wt_fsh_{k+1}'][-1][1:] for k in fleets}
  def yld(F,sel='sel_msy'):
   fs={k:[F*rat[k]*v for v in d[sel][k]] for k in fleets}
   Z=[M[a]+sum(fs[k][a] for k in fleets) for a in range(12)];sur=[math.exp(-z) for z in Z]
   n=[1.]
   for a in range(11):n.append(n[-1]*sur[a])
   n[-1]/=(1-sur[-1])
   phi=sum(n[a]*sur[a]**(9.5/12)*mature[a] for a in range(12))
   R=(phi-alpha)/(beta*phi)
   Y=R*sum(sum(wf[k][a]*n[a]*fs[k][a]*(1-sur[a])/Z[a] for a in range(12)) for k in fleets)
   return {'F':F,'SSB_kt':phi*R,'Yield_kt':Y,'Recruitment':R}
  optimumF=maxim(lambda f:yld(f)['Yield_kt'])
  scalarF=.8*M[0]
  newton_trace=[]
  for _ in range(8):
   f2=scalarF+.5e-5;f3=f2-1e-5
   y1=yld(scalarF)['Yield_kt'];y2=yld(f2)['Yield_kt'];y3=yld(f3)['Yield_kt']
   dy=(y2-y3)/1e-5;dyy=(y2+y3-2*y1)/(.25e-10)
   scalarF-=dy/dyy
   newton_trace.append(scalarF)
  profiles=[]
  for i,x in enumerate((ROOT/(model+'.yld')).read_text().splitlines(),1):
   try:v=list(map(float,x.split()))
   except:continue
   if len(v)==7 and v[0]==stock:profiles.append((i,v))
  maxrow=max(profiles,key=lambda x:x[1][3]); pe=yld(maxrow[1][1]); pe3=yld(maxrow[1][1],'sel_fut')

  assert all(abs(v)<1e-12 for v in params['rec_dev_future']), 'Nonzero future recruitment deviation'
  terminalN=next(v[1:] for v in d['N'] if v[0]==2026)
  termZ=[M[a]+sum(fa[k][a] for k in fleets) for a in range(12)]
  terminalSSB=sum(terminalN[a]*math.exp(-termZ[a]*9.5/12)*mature[a] for a in range(12))
  nstart=[terminalSSB/(alpha+beta*terminalSSB)]
  for a in range(11):nstart.append(terminalN[a]*math.exp(-termZ[a]))
  nstart[-1]+=terminalN[-1]*math.exp(-termZ[-1])
  fs={k:[scalarF*rat[k]*v for v in d['sel_fut'][k]] for k in fleets}
  z=[M[a]+sum(fs[k][a] for k in fleets) for a in range(12)]
  ssb2027=sum(nstart[a]*math.exp(-z[a]*9.5/12)*mature[a] for a in range(12))
  catch2027=sum(sum(wf[k][a]*nstart[a]*fs[k][a]*(1-math.exp(-z[a]))/z[a] for a in range(12)) for k in fleets)
  savedSSB=d['SSB_fut_4'][0][1];savedCatch=d['Catch_fut_4'][0][1]
  projectioncheck={'year':2027,'scenario':4,'reconstructed_SSB_kt':ssb2027,'saved_SSB_kt':savedSSB,'SSB_difference_kt':ssb2027-savedSSB,'reconstructed_Catch_kt':catch2027,'saved_Catch_kt':savedCatch,'Catch_difference_kt':catch2027-savedCatch,'note':'Forward calculation from rounded terminal numbers, mortality, selectivity, weights, BH curve and reconstructed scalar F; recruitment deviation zero.'}
  ref={'model':model,'stock':stock,'report':str(ROOT/filename),'msy_mt_label_line':ln['msy_mt'],
       'annual_2026_Fmsy':annual[4],'annual_2026_Bmsy_kt':annual[9],'annual_2026_MSY_kt':annual[7],
       'fixed_2017_2026_Bmsy_kt':sum(v[9] for v in d['msy_mt'] if 2017<=v[0]<=2026)/10,
       'reconstructed_scalar_jjm_tpl':yld(scalarF),
       'jjm2_evaluator_at_same_F':yld(scalarF,'sel_fut'),
       'projection_2027_validation':projectioncheck,
       'converged_equilibrium_optimum_F':optimumF,
       'newton_8_iteration_trace':newton_trace,
       'saved_profile_max_grid':{'source':str(ROOT/(model+'.yld')),'line':maxrow[0],'F':maxrow[1][1],'B_kt':maxrow[1][2],'Y_kt':maxrow[1][3], 'reconstructed_15yr_B_kt':pe['SSB_kt'],'reconstructed_3yr_B_kt':pe3['SSB_kt'],'reconstructed_15yr_Y_kt':pe['Yield_kt']},
       'Fratio':{str(k+1):v for k,v in rat.items()},
       'base_output_has_jjm2_replacement_fields':'repl_status' in d,
       'note':'Scalar is numerical reconstruction of jjm.tpl no-year equilibrium equations from rounded saved reports, not a named scalar in the report and not an assessment rerun. F uses eight Newton iterations under sel_msy (2011-2025). Saved .yld profiles match this 15-year evaluator; hypothetical current jjm2 evaluator under sel_fut (2023-2025) is shown separately and is not asserted to describe saved runs.'}
  records.append(ref)
print(json.dumps(records,indent=2))
(OUT/'reference_points_values.json').write_text(json.dumps(records,indent=2)+'\n')

validation={'records':[dict(model=r['model'],stock=r['stock'],**r['projection_2027_validation']) for r in records], 'status':'PASS','max_abs_SSB_difference_kt':max(abs(r['projection_2027_validation']['SSB_difference_kt']) for r in records),'max_abs_Catch_difference_kt':max(abs(r['projection_2027_validation']['Catch_difference_kt']) for r in records),'tolerance_kt':0.02,'source_precision_note':'Reports use rounded numbers, selectivity and weights; values are numerical reproductions, not named scalar outputs.'}
assert validation['max_abs_SSB_difference_kt'] < validation['tolerance_kt']
assert validation['max_abs_Catch_difference_kt'] < validation['tolerance_kt']
(OUT/'reference_points_numerical_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
