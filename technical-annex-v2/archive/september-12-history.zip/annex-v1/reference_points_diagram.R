library(grid)
args <- commandArgs(trailingOnly=TRUE)
out <- if(length(args)) args[[1]] else dirname(normalizePath(sub('^--file=', '', grep('^--file=', commandArgs(), value=TRUE)[1])))
dir.create(out, recursive=TRUE, showWarnings=FALSE)
ink <- '#1c2d39'; blue <- '#205878'; orange <- '#8a4a14'
lab <- function(x,y,s,size=14,col=ink,font=1,just=c('left','top')) grid.text(s,x,y,just=just,gp=gpar(fontfamily='sans',fontsize=size,col=col,fontface=font))
box <- function(x,y,w,h,color,title,lines,sizes) {
 grid.roundrect(x,y,w,h,r=unit(.012,'npc'),just=c('left','bottom'),gp=gpar(col=color,fill=if(color==blue)'#f5f9fc' else '#fff8f0',lwd=1.4))
 lab(x+.018,y+h-.022,title,15,color,2)
 for(i in seq_along(lines)) lab(x+.018,y+h-.065-(i-1)*.047-if(grepl('^3 ',title)&&i==3).027 else 0,lines[[i]],sizes[i])
}
arr <- function(x1,y1,x2,y2,col) grid.lines(c(x1,x2),c(y1,y2),arrow=arrow(type='closed',length=unit(.13,'inches')),gp=gpar(col=col,fill=col,lwd=1.5))
draw <- function() {
 grid.newpage();grid.rect(gp=gpar(fill='white',col=NA))
 lab(.04,.965,'Reference points and projections in jjm.tpl',24,font=2)
 lab(.04,.92,'2026 single-stock example  |  Biomass = spawning biomass in million tonnes (Mt)',13,col='#45545e')
 box(.04,.642,.425,.225,blue,'1  Annual reference points - base model',list(
  'Each year: selectivity, fleet shares, M and weights',
  expression(F[MSY*","*t]==arg*max[f]~Y[eq*","*t](f)),
  expression('2026: '~F[MSY]==0.7946~~';'~~B[MSY]==6.335~Mt)),c(12,18,16))
 box(.535,.642,.425,.225,orange,'2  Projection MSY - model (.ls)',list(
  'Optimize with mean selectivity for 2023-2025',
  expression(F[MSY]^proj==arg*max[f]~Y[eq]^3*(f)),
  expression(F[MSY]^proj %~~% 0.9252~~';'~~B[MSY]^eq %~~% 5.667~Mt)),c(12,18,16))
 arr(.252,.63,.252,.566,blue);arr(.747,.63,.747,.566,orange)
 box(.04,.33,.425,.224,blue,'3  Fixed biomass target - base model',list(
  'Average annual BMSY for 2017-2026',
  expression(bar(B)[MSY]==frac(1,10)*sum(B[MSY*","*t],t==2017,2026)),
  'Status and risk threshold: 6.869 Mt'),c(13,17,17))
 box(.535,.33,.425,.224,orange,'4  Project scenario 4 - model (.ls)',list(
  'Apply projection FMSY with the same selectivity',
  expression(F[k*","*y*","*a]^{(4)}==p[k*','*2026]*F[MSY]^proj*bar(v)[k*","*a]^3),
  'Advance numbers at age to biomass and catch'),c(12,18,13))
 arr(.252,.318,.38,.246,blue);arr(.747,.318,.62,.246,orange)
 grid.roundrect(.18,.10,.64,.135,r=unit(.012,'npc'),just=c('left','bottom'),gp=gpar(fill='#f8fafc',col='#475569',lwd=1.4))
 lab(.5,.214,'Compare projected biomass with the fixed base target',15,font=2,just=c('centre','top'))
 lab(.5,.168,expression('2028: '~hat(B)==5.774~Mt~~';'~~P(B>6.869~Mt) %~~% 17*'%'),17,just=c('centre','top'))
 lab(.5,.126,'Projected catch = 1.236 Mt; conditional normal probability with new ADMB standard errors',11,just=c('centre','top'))
 lab(.04,.059,'Separate global reference, using 2011-2025 selectivity: base BMSY = 6.546 Mt; precautionary (.ls) BMSY = 5.750 Mt.',10.5,col='#45545e')
 lab(.04,.034,'Corrected jjm.tpl, 11 September 2026. Fitted parameters retained; projections and standard errors extend through 2036.',10.5,col='#45545e')
}
png(file.path(out,'reference-points-diagram.png'),width=2550,height=1870,res=170,type='cairo');draw();dev.off()
svglite::svglite(file.path(out,'reference-points-diagram.svg'),width=15,height=11);draw();dev.off()
cairo_pdf(file.path(out,'reference-points-diagram.pdf'),width=15,height=11);draw();dev.off()
