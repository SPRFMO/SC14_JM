# Word layout review

Artifact: `output/technical-annex.docx`. Render inspected: `validation/annex-word/page-*.png`, 12 September 2026. Inventory contained **126 pages**. This review individually opened **all pages 1–35** with `view_image` in seven batches of five. Pages 36–126 were assigned for separate review by the parent agent. This record concerns the initial render; it does not certify later revised output.

**Status: corrections required before delivery.** No document or source edits were made during this layout review.

## Required corrections

| Pages | Finding | Action |
|---|---|---|
| 1 | The “Table of contents” heading appears with an empty field and whitespace beneath it, immediately before Introduction. | Populate the TOC and verify its rendered entries/page numbers. |
| 8, 12, 19 | Figures 1, 2 and 3 are clipped along the right side. The right-hand diagram boxes terminate at the image boundary, with the figure extending beyond its usable container. | Fit the complete image within the available width, preserving aspect ratio, and inspect all diagram edges after rendering. |
| 10, 11, 23 | Native equations (2), (3), (6), (12) and (13) show literal `&` alignment markers. Alignment is malformed. | Repair the math conversion/alignment while retaining every mathematical term; inspect the new Word equations individually. |
| 14–15 | Table 6 caption is stranded at the bottom of page 14; the entire table begins on page 15. | Keep the caption with the first table row. |
| 15 | Table 6 header “Component” breaks as “Componen” and “t”. | Increase the column's usable width or adjust padding/font size; retain the original wording. |
| 16 | Risk Tables 7–8 split numeric values across lines: e.g. 10,880 becomes “10,88” above “0”; 14,110 becomes “14,11” above “0”. Similar wrapping affects 10,944 and 13,275. | Give numeric columns enough width; use landscape layout or balanced widths/padding if needed. Preserve all original headers and values. |
| 16–17 | Table 8 continues onto page 17 without its column header. Only the last two scenario rows appear at the top of page 17. | Repeat the table header or keep this short six-row table together. |
| 34–35 | Table 14 is unreadable: “Year” and four-digit years stack one character per line; two-digit length headers and many values split vertically. Landscape orientation alone has not provided adequate usable cell width. | Reduce excessive cell padding and allocate a usable Year column; if needed, split into explicitly labelled horizontal panels with a repeated Year column. Preserve every native length-bin header, year and value. |

## Other corrections and observations

- Page 8 begins “Figure Figure 1”; page 15 begins “Tables Table 7, Table 8 and Table 9”. Remove the redundant manual prefix before automatic cross-references.
- Page 26 is almost entirely blank and landscape, containing only the Tables heading and introductory paragraph. Table 10 starts on portrait page 27. Review section/page-break placement so the introduction can accompany its first table.
- The inspected pages have no visible page numbers. Page numbering would support navigation and review of a 126-page technical annex.
- References on pages 24–25 contain two entries for the SC13 Annex 11 (2025a and 2025b). This is a bibliography duplication to reconcile, rather than a clipping defect.
- Figure captions 1–3 stay with their figures. Their present issue is image clipping.
- Tables 2–5 fit and retain legible headings and values. Table 9 fits. Tables 10–13 on pages 27–33 are legible and their continued pages repeat the headers.
- Normal prose on inspected pages has no visible clipping or overlap. Page 25 has substantial whitespace after the final references; its following Tables section starts separately.

## Inspection coverage

Individually inspected pages: **1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35**.

Pages with no additional layout findings beyond those listed above: 2–7, 9, 13, 18, 20–22, 27–33. Pages 1–5 were opened at the tool's high-detail setting; pages 6–35 used original image detail. No contact-sheet-only inspection was used. Final approval requires inspection of the complete corrected render, including pages inspected by other agents.

## Scoped equation and diagram fixes

The five affected equation groups now use a Word-compatible `gathered` layout with their mathematical terms and labels preserved. The three complete static PNGs have explicit 6.4-inch print widths. The duplicate manual `Figure` prefix was removed from the reference-point discussion.

All eight pages of the isolated `math-test/complete.docx` fixture were rendered with bundled LibreOffice and inspected individually at original detail. The five native OMML equation groups, equation numbers/references, three complete diagrams and their captions passed visual inspection. Structural checks found no literal ampersands in the math and confirmed all three image widths. See `math-test/README.md`, `math-test/native-word-checks.json` and `math-test/source-equivalence.json` for evidence. This scoped result precedes full-annex integration and does not certify the old 126-page output or resolve the separate table/TOC findings above.
