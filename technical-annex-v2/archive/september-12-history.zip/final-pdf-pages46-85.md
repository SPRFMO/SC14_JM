# PDF visual review: pages 46–85

Reviewed 12 September 2026. All **40 pages, 46 through 85 inclusive**, were inspected individually at original detail from 144-dpi Poppler images, rather than a contact sheet. Images are `validation/annex-pdf-pass2/page-046.png` through `page-085.png`.

The reviewed snapshot was the 117-page `output/technical-annex.pdf` created at 13:25 local time. Subsequent source corrections and a later render require focused verification; the observations below describe this snapshot.

## Actionable findings

1. **Figure 10, page 79: total biomass labelled as spawning biomass.** `report/annex_plots.qmd` used `what="biomass"` with a spawning-biomass title, caption and alternative text. The active installed `jjmR` namespace maps `biomass` to `TotBiom` and `ssb` to `SSB` in `.reshapeJJM`; the matching repository source is `../jjmR/R/jjm.output-internal.R:1–8`. The displayed terminal value is consistent with saved total biomass (9,254.66 kt in 2026), whereas historical Table 36 uses SSB (6,109 kt after rounding). Keep the historical plotted data and correct the title to **Total biomass (kt)** and the caption/alternative text to total biomass. Root received this confirmed correction before the final build.

2. **Figures 14–16, pages 83–85: predicted-series legend symbol differs from the plotted geometry.** The legend shows a solid black dot for Predicted; the fitted series and captions use lines. The observed box is visible. `../jjmR/R/jjm.diag-internal.R:1236–1243` specifies `pch=19`, while the panel draws `panel.lines` at line 1265; survey compositions have the same pattern at lines 1499–1530. A report-level trellis key with an Observed rectangle and Predicted line corrects this without changing predictions. The `pch=-1` warning concerns the invisible observed point and does not explain away the visible predicted dot.

3. **Figure 9, page 78: caption nearly touches the page footer.** Both recruitment panels, axes and the entire caption are present, but the final caption line sits only a few pixels above page number 78. Reduce this paired figure's height modestly. Its existing caption also says “southern stock recruitment” before referring to both southern and Far North panels; a caption describing recruitment for both stocks is clearer.

4. **Caption units:** Tables 37–39 (pages 55, 57, 59) omit the abundance scale, and Tables 40–42 (pages 61, 63, 65) omit the time unit for fishing mortality. Figures 6–11 (pages 75–80) omit biomass/recruitment units in their captions and lack a definition of the shaded bands. Verified additions are millions of fish for numbers/recruitment, thousand tonnes for biomass, and per year for fishing mortality. Preserve the exact native table headers and data.

5. **Minor pagination:** Table 33 has a single continuation row at the top of page 51, with the header repeated correctly. It is fully legible. Page 73 contains only the projection-link paragraph before the Figures section; this is excess whitespace rather than missing content.

The old “current” five-year projection wording remains visible on page 73 of the reviewed snapshot. Root had already corrected the source to distinguish earlier five-year projections from the updated ten-year risk summaries; verify that wording in the final render.

## Unit and uncertainty trace

- Tables 37–39 directly use saved `$N`, with rounding only (`annex_tables.qmd`); there is no R-side abundance conversion.
- Frozen `software/model-projection/jjm.tpl:2783` computes total biomass as `natage * wt_pop`. The catch path at lines 2870–2871 uses the same abundance scale multiplied by fishery weight. Catch input is copied unchanged at line 1278.
- Saved N multiplied by saved `wt_a_pop` reproduces all three total-biomass time series to the precision of the text outputs: maximum relative discrepancies are 5.13e-6 for h1, 3.99e-6 for h2 South, and 1.66e-6 for h2 Far North. These are rounding differences. Native biomass is in thousand tonnes and individual weights are in kg, so native abundance is in millions of fish. Saved age-1 N and recruitment agree.
- Active `plot.jjm.retro` defaults to `ci=TRUE, std=FALSE`. `.plotRetro` passes the saved mean/lower/upper columns to `.linesCI`, which shades the interval (`../jjmR/R/retro.R:161–219`). Frozen `jjm.tpl` writes log-scale bounds using the estimate and reported standard error. Caption wording “Shading shows the saved model uncertainty bounds” is justified without asserting exact 95% coverage.
- Retrospective legend 0 denotes the full assessment and 1–5 the successive terminal-year peels. All six legend entries are visible in this snapshot.

## Page-by-page record

| Page | Content checked | Visual result |
|---:|---|---|
| 46 | Table 26, Fleet 4 weights, 1970–2006 | Complete caption, kg units and age headers; all values fit. |
| 47 | Table 26 continuation, 2007–2026 | Repeated headers and complete final row; no wrapping. |
| 48 | Table 27 input-year inventory | Complete multiline caption, source names and year ranges fit. |
| 49 | Tables 28–30 definitions, native equations, objective | All mathematical terms visible within margins; compact rows remain legible. |
| 50 | Tables 31–33 observation weights and selectivity | Headers, ranges and phase values fit; Table 33 continues. |
| 51 | Table 33 continuation and Table 34 | One-row continuation is intact; Table 34 complete. |
| 52 | Table 35 assessment progression | Descriptions wrap cleanly; model identifiers and all rows visible. |
| 53 | Table 36 historical SSB, 1970–2006 | Caption and thousand-tonne scale visible; numeric columns distinct. |
| 54 | Table 36 continuation, 2007–2026 | Repeated headers; terminal blanks for older assessments are intact. |
| 55 | Table 37 h1 N-at-age, 1970–2006 | Layout clean; abundance scale omitted from caption. |
| 56 | Table 37 continuation, 2007–2026 | All ages and final row fit. |
| 57 | Table 38 h2 South N-at-age, 1970–2006 | Layout clean; abundance scale omitted from caption. |
| 58 | Table 38 continuation, 2007–2026 | All values and repeated headers fit. |
| 59 | Table 39 h2 Far North N-at-age, 1970–2006 | Layout clean; abundance scale omitted from caption. |
| 60 | Table 39 continuation, 2007–2026 | All values and repeated headers fit. |
| 61 | Table 40 h1 F-at-age, 1970–2006 | Decimal values fit; caption should state per year. |
| 62 | Table 40 continuation, 2007–2026 | No clipped or wrapped decimals. |
| 63 | Table 41 h2 South F-at-age, 1970–2006 | Decimal values fit; caption should state per year. |
| 64 | Table 41 continuation, 2007–2026 | Repeated headers and final row complete. |
| 65 | Table 42 h2 Far North F-at-age, 1970–2006 | Decimal values fit; caption should state per year. |
| 66 | Table 42 continuation, 2007–2026 | Repeated headers and final row complete. |
| 67 | Table 43 h1 summary, 1970–2006 | Unit-bearing headers wrap cleanly; numeric columns distinct. |
| 68 | Table 43 continuation, 2007–2026 | No clipped values; terminal row intact. |
| 69 | Table 44 h2 South summary, 1970–2006 | Caption/header complete; all values fit. |
| 70 | Table 44 continuation, 2007–2026 | Complete repeated headers and values. |
| 71 | Table 45 h2 Far North summary, 1970–2006 | Caption/header complete; all values fit. |
| 72 | Table 45 continuation, 2007–2026 | Complete repeated headers and values. |
| 73 | Projection/risk cross-reference paragraph | All references resolved; older wording already corrected in source. |
| 74 | Figure 4 catch by fleet | Four legend labels, kt axis, entire plot and caption visible. |
| 75 | Figure 5 data inventory and Figure 6 h1 SSB retrospective | Both figures and captions complete; retrofit caption units/bands. |
| 76 | Figure 7 h1 recruitment retrospective | Lines, bands, six legend entries and caption complete; units omitted. |
| 77 | Figure 8 two-stock SSB retrospective | Both panels complete, caption together; lower legend remains readable over pale band. |
| 78 | Figure 9 two-stock recruitment retrospective | All content present; caption/footer gap too small. |
| 79 | Figure 10 historical total biomass | Plot complete; incorrect spawning-biomass label confirmed and reported. |
| 80 | Figure 11 historical recruitment | Plot, legend and caption fit; caption units/band definition omitted. |
| 81 | Figure 12 fishery weights | All four panels, age legend and kg caption visible. |
| 82 | Figure 13 survey/index weights | All six panels, age legend and kg caption visible. |
| 83 | Figure 14 h1 N Chile composition fit | All years, proportions and caption fit; predicted legend dot should be a line. |
| 84 | Figure 15 h2 N Chile composition fit | All years, proportions and caption fit; same legend mismatch. |
| 85 | Figure 16 h1 SC Chile composition fit | All years, proportions and caption fit; same legend mismatch. |

## Scope

This is a visual and source-mapping review of saved assessment products. No model was rerun and no scientific data were changed. Source edits were limited to the separately authorized Eq. 8 line break in `annex_hcr_2022.qmd`; all other findings were sent to root for scoped fixes and final rendering.
