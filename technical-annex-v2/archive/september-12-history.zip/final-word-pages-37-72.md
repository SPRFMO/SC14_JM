# Individual Word-page review: pages 37–72

Every page from 37 through 72 of the 108-page render in `validation/annex-word-final/` was viewed individually at original image detail. This review records the render available before the subsequent global numerical-alignment, data-coverage width, and model-register formatting corrections. No report sources were edited during this review.

## Findings

No page-margin clipping, digit wrapping, detached captions, blank pages, missing continuation headers, or cut-off equations was observed in this range. These pages contain tables rather than figures. The index table's earlier crowding and the maturity table's broken stock names are resolved. The corrected CV table on page 51 is legible and displays the independently verified values.

Three residual issues were reported promptly for correction:

1. Some numerical cells have inconsistent horizontal alignment, causing values to crowd shared column borders even when ample column width is available. Examples include page 42, year 2001, age 1/2 (`0.117` / `0.116`); page 54, year 1970, current-model SSB (`13,315`) beside the Year column; and page 57, year 2004, ages 5/6 (`3,150` / `1,372`). Gridlines and complete digits retain the distinctions. This issue also appears in several mortality and summary tables. Explicit right alignment of all numeric body cells is appropriate.
2. Page 49, Table 27: `Peru_Artis_CPUE` wraps with its final `E` on a separate line. Increase the Source column width while retaining room for coverage years.
3. Page 53, Table 35: the Model column wraps group labels within words and over several lines. Model identifiers lose trailing zeros (`0.00` becomes `0`, `0.10` becomes `0.1`, `1.00` becomes `1`). Preserve identifier strings and give this column an explicit width.

## Page-by-page record

| Page | Observation |
|---:|---|
| 37 | Table 17 index inputs: caption attached; all headers fit; years and values are complete. Early empty observation rows occupy much of the page but are intentional data coverage. |
| 38 | Table 17 continuation: repeated headers; numeric columns separated; final 2026 row and following paragraph contained. |
| 39 | Tables 18–19 acoustic age compositions: captions attached; all values contained. Some cells have inconsistent alignment and tight neighboring values. |
| 40 | Tables 20–22: maturity stock labels now fit. Growth and ageing-error tables are readable; no clipping or detached captions. |
| 41 | Table 23 body mass, start: caption/header attached; no wrapped digits. Occasional numerical alignment inconsistency. |
| 42 | Table 23 continuation: repeated headers; clear years; alignment crowding in some cells, including 2001 ages 1/2 and 2016 ages 9/10. |
| 43 | Table 24 body mass, start: caption/header attached; all values contained. |
| 44 | Table 24 continuation: repeated headers; occasional alignment crowding, no lost digits. |
| 45 | Table 25 body mass, start: caption/header attached; recurring alignment crowding in several rows. |
| 46 | Table 25 continuation: repeated headers; readable, contained, no clipping. |
| 47 | Table 26 body mass, start: caption/header attached; recurring alignment crowding in several rows. |
| 48 | Table 26 continuation: repeated headers; recurring alignment crowding, values complete. |
| 49 | Table 27 coverage: caption attached; no numerical clipping. Source name Peru_Artis_CPUE splits before final E; year ranges otherwise wrap acceptably. |
| 50 | Tables 28–29 definitions and equations: legible, complete, and contained. Table 30 begins with its caption, header, and several rows together. |
| 51 | Table 30 continuation repeats its header. Table 31 CVs is correct and clear. Table 32 selectivity mapping fits completely, with legible long headers. |
| 52 | Tables 33–34 selectivity mappings: readable, contained, captions attached. No continuation-header issue remains. |
| 53 | Table 35 model progression: Model column wraps group labels poorly and loses identifier trailing zeros; description column and caption remain contained. |
| 54 | Table 36 historical SSB, start: years now have no thousands separators. Some current-model cells align left beside Year while most align right; all digits present. |
| 55 | Table 36 continuation: repeated headers; years and values readable and contained. |
| 56 | Table 37 abundance, start: caption/header attached; five-digit numbers fit; no clipping. |
| 57 | Table 37 continuation: repeated headers; several neighboring age-5/6 numbers crowd the border because of inconsistent alignment. |
| 58 | Table 38 abundance, start: caption/header attached; numbers fit and remain readable. |
| 59 | Table 38 continuation: repeated headers; age-5/6 alignment crowding in some rows; complete values. |
| 60 | Table 39 abundance, start: caption/header attached; readable and contained. |
| 61 | Table 39 continuation: repeated headers; readable and contained. |
| 62 | Table 40 mortality, start: caption/header attached; repeated alignment crowding, without digit wrapping or clipping. |
| 63 | Table 40 continuation: repeated headers; same alignment issue, all values complete. |
| 64 | Table 41 mortality, start: caption/header attached; readable and contained. |
| 65 | Table 41 continuation: repeated headers; some alignment crowding, complete values. |
| 66 | Table 42 mortality, start: caption/header attached; some alignment crowding, complete values. |
| 67 | Table 42 continuation: repeated headers; readable and contained. |
| 68 | Table 43 summary, start: long headers wrap acceptably; caption attached. A few 1997–1998 cells shift alignment, without lost digits. |
| 69 | Table 43 continuation: repeated headers; readable and contained. |
| 70 | Table 44 summary, start: caption attached; readable and contained. |
| 71 | Table 44 continuation: repeated headers; readable and contained. |
| 72 | Table 45 summary, start: caption attached; headers fit. Some 1997–1998 cells shift alignment, without lost digits. |

Follow-up should inspect representative pages after the three reported corrections, especially the historical-SSB table, one body-mass table, one mortality table, the model register, and the coverage table. This visual review evaluates presentation; separate numerical/source validations establish scientific values.
