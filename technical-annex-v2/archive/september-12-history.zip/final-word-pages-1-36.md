# Final Word layout review: pages 1–36

Reviewed 12 September 2026. Image set: `validation/annex-word-final/page-1.png` through `page-108.png`. This review individually opened **every page 1–36** at original image detail, in nine batches of four. It is limited to that rendered snapshot; later corrections require a focused recheck.

**Status: one required numeric-width correction and one table-alignment correction remain in this range.** Native equation and diagram repairs pass in the full document.

## Remaining findings

| Page(s) | Finding | Required follow-up |
|---|---|---|
| 16 | Table 7, F = 0: biomass 10,880 and 14,110 wrap as `10,88` / `0` and `14,11` / `0`. Table 8 has the same problem for 10,944 and 13,275. | Increase usable widths of the biomass columns while preserving every heading/value and the adjacent probability definitions. Inspect the revised risk tables. |
| 26–36, intermittently | Some numeric cells use a different horizontal alignment from neighboring rows. Adjacent values approach the divider closely: page 30 Table 13, 2022 age 1/2 values 1 and 67 resemble `167`; 2025 values 22 and 56 resemble `2256`. Page 33 Table 15, 1979 length 26/27 values 5 and 7 similarly resemble `57`. The issue recurs in several rows of the length panels. | Apply consistent numeric alignment and sufficient cell padding across all rows without changing native cell values. Inspect representative affected rows after formatting. |
| 23 | Both SC13 Annex 11 bibliography entries remain visible as 2025a and 2025b. | Consolidate the duplicate citation keys as described in `final-editorial-review.md`; this is editorial rather than clipping. |

## Passed checks and coverage

- **Pages 1–2:** title and populated linked contents are legible. No overlaps or clipping. Contents use links rather than printed page locators.
- **Pages 3–8:** narrative, current/historical status, headings, citations and Table 1 fit. The former duplicate “Figure Figure 1” prefix is corrected.
- **Page 9:** Figure 1 is complete, including both right-side boxes and the bottom notes. Caption remains with the figure. Table 2 fits with intact headings and values.
- **Pages 10–12:** Table 3 and the reference-pathway table fit. Equations 1–6 are native, complete and legible; the three revised reference-point equation groups are free of literal alignment markers. Grouped equations remain intact on individual pages.
- **Pages 13–14:** Figure 2 is complete, including “Also required”, TAC = 0, Method 3 and bottom notes. Its caption stays with the diagram. Equations 7–10 and Tables 4–5 fit.
- **Page 15:** Table 6 now stays with its caption. Its model/component headings and all numerical values fit. The probability equation fits.
- **Pages 16–17:** All six rows of each risk table stay together, and captions remain with their tables. Table 9 is legible. The remaining risk-value wrapping is confined to the values identified above on page 16.
- **Pages 18–20:** Figure 3 is complete and legible with its caption on page 18. Working advice status and cumulative assessment history flow without clipping or overlap.
- **Pages 21–22:** Equations 11–13 are complete and legible; the two newly revised history groups retain all their terms without stray ampersands. Bibliography begins cleanly.
- **Page 23:** References fit, subject to the duplicate SC13 entry identified above.
- **Pages 24–25:** Catch Table 10 begins with the Tables introduction and repeats its header on the continuation page. The previous nearly blank landscape Tables page has been removed.
- **Pages 26–30:** Native age-bin headings and four-digit years in Tables 11–13 fit. Continuation pages repeat the age headings. No clipping or split numeric digits; inconsistent alignment is identified above.
- **Pages 31–36:** All three length panels fit: 10–23, 24–37 and 38–50 cm. Native length-bin headings, four-digit years, captions and the 50 cm plus qualification are intact. Each panel's continuation page repeats Year, Fork length and every bin heading. The old one-character-per-line collapse is resolved; intermittent horizontal alignment still warrants correction.

Individually inspected pages: **1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36**. No contact-sheet-only inspection was used. Pages 37–108 are assigned to separate reviewers.
