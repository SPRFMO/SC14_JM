# PDF visual review — pages 1–45

Reviewed the 117-page PDF generated on 12 September 2026 at 12:25:30 UTC. The review covers PDF pages 1–45, rasterized at 144 dpi to `validation/annex-pdf-pass2/page-001.png` through `page-045.png`. All 45 pages were viewed in labelled contact sheets; equations, diagrams and representative large tables were additionally viewed at original 1191 × 1684 raster detail (pages 4, 8–12, 15, 17, 20, 23, 30, 36, 38–40).

## Findings communicated before the next build

1. **Page 4, section 1.6: malformed degree symbol.** The PDF visibly displays a square between 15 and C. Parent has corrected the source from superscript zero to `15 °C`; verify the rebuilt PDF.
2. **Page 12, equation (8): crowded equation tag.** The final `C_F = C_(t+1)(F_MSY)` definition ends directly against `(8)` at the right edge. Two aligned lines would restore separation. No mathematical term is clipped. Equation (5), page 10, is also close to its tag, but has a visible gap.
3. **Page 39, Table 22: ageing-error caption reverses the matrix orientation.** The displayed matrix follows the retained `1.06.dat` rows; its columns sum approximately to one. The source applies `age_err * true-age vector` in `jjm.tpl` lines 2727 and 2757. Thus rows are observed ages and columns are true ages. This is a caption correction only; the current ageing-error option is disabled and the numeric cells should stay unchanged.
4. **Pages 14–15, Tables 7–9: risk tables extend slightly beyond the normal right text edge.** Every column and numeric cell remains visible in this snapshot. Parent reported that the table-width fix is already assigned; verify its next render.

## Page coverage

| PDF page(s) | Content and visual assessment |
|---|---|
| 1 | Title and contents are clean. Contents continues by two entries onto page 2. |
| 2 | Contents continuation, introduction and development chronology fit. |
| 3 | Stock structure, fishery and management paragraphs fit without clipping. |
| 4 | Data narrative fits; malformed degree glyph flagged above. |
| 5 | Survey/data/biological narrative is intact. |
| 6 | Population-model and model-development narrative fit. |
| 7 | Model bridge and dynamic-reference equation are complete. |
| 8 | Reference-point diagram fits, labels and arrows are intact; Tables 2 and 3 are legible. Table 3 continues onto page 9 with its header repeated. |
| 9 | Table 3 continuation and equations (1)–(3) are complete, with fractions, sums, signs and tags visible. |
| 10 | Definitions table and equations (4)–(6) fit; equation (5) tag has a narrow but visible gap. |
| 11 | Annex K decision diagram, source note, arrows and text fit. |
| 12 | Equations (7)–(9) and HCR table fit; crowded equation (8) tag flagged above. |
| 13 | Biomass-band table, equation (10), stock summary and narrative fit. |
| 14 | Risk explanation and start of Table 7 are intact; table width flagged above. |
| 15 | Tables 7–9 and following narrative remain readable; every rightmost catch column is visible. |
| 16 | Replacement-yield, exploratory uncertainty and advice text fit. |
| 17 | Stock-recruitment diagram and advice paragraphs are intact. |
| 18 | Two-stock advice, assessment issues and history-section introduction fit. |
| 19 | Historical bridge and composition/CPUE provenance are intact. |
| 20 | Survey-age equation (11), growth equation (12), and finite-bin conversion (13) all render cleanly. Fractions, summation subscripts, hats and Greek symbols are intact. |
| 21 | Estimation history and references fit. Parent has identified and corrected duplicate bibliography entries for the next build. |
| 22 | Final reference entries fit; the remaining page space is blank. |
| 23–24 | Catch table fits and repeats its header across the page break. Compact numeric font is readable at original raster detail. |
| 25–26 | Fleet 1 age-composition table fits; no columns or terminal-year rows are clipped. |
| 27–28 | Fleet 2 age-composition table fits with repeated header. |
| 29 | Fleet 4 age-composition table fits. |
| 30–31 | Fleet 3 length panel 1 (10–23 cm) fits; header repeats and terminal-year rows are visible. |
| 32–33 | Fleet 3 length panel 2 (24–37 cm) fits with complete rows/columns. |
| 34–35 | Fleet 3 length panel 3 (38–50 cm) fits; the caption explicitly identifies the 50 cm plus observation category. |
| 36–37 | Six-series index table fits; all series names and numeric cells are visible. The many initial blank years are explicit table rows, consistent with the displayed data range. |
| 38 | Two acoustic age-composition tables fit without overflow. |
| 39 | Maturity, growth/mortality and ageing-error tables fit; matrix-orientation caption correction flagged above. |
| 40–41 | Fleet 1 weights-at-age table fits with repeated header. |
| 42–43 | Fleet 2 weights-at-age table fits with repeated header. |
| 44–45 | Fleet 3 weights-at-age table fits with repeated header; all terminal-year entries are visible. |

The reviewed pages contain no clipped equations, missing table columns, overlaps between figures and captions, or accidental blank pages. The first diagnostic plot legends occur later in the document and are outside this assigned page range. This review records the current snapshot; the issues above require checking against the next PDF build.

## Snapshot identity

- PDF SHA256: `8e683a0256e44f6d4f36fff197fed96ea88cd4d2c228e7e07f9ea87cca110b1a`
- PDF modification time (UTC): 2026-09-12T12:25:30.510989+00:00
- Review written (UTC): 2026-09-12T12:31:58.964738+00:00
