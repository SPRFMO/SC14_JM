# Word release-layout review, pages 73–107

All 33 changed page images in this range were inspected individually: page 74 and pages 76–107. Pages 73 and 75 are image-identical to the previously reviewed version. The figures, tables, legends, panel labels and complete captions fit the page. The two-stock projection figures run across pages with complete labelled panels and their full captions after panel (b).

Age-composition legends now show predicted lines; length-composition legends/captions correctly show predicted points. Historical Figure 10 is labelled total biomass with kt units. Retrospective captions define units, peels and saved uncertainty bounds. Projection captions identify the earlier five-year products.

A subsequent narrow update adds the SSB rho endpoint qualification to prose and two captions. Its affected pages receive a separate final comparison/review.
