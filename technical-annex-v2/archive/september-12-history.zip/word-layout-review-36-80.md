# Word layout review: pages 36–80

Reviewed every page individually in `validation/annex-word/page-N.png`, rather than relying on a contact sheet. This records the initial 126-page Word render, before layout corrections requested during review. Page numbering may change after correction. No report layout edits were made by this reviewer.

## Findings requiring correction

- Pages 36–40: the 41-bin length-composition table fits within the page but has columns too narrow for its content. Year labels, bin headers, and values with two or more digits wrap one character per line. This is a major readability problem. Splitting the length bins into multiple panels/tables is preferable to further shrinking the type.
- Page 41 is completely blank, apparently at an orientation transition.
- Pages 42–43, Table 15: numeric columns have inadequate separation, particularly Chile_CPUE and Peru_Artis_CPUE; adjoining values can appear to be one number. The final header also wraps awkwardly.
- Page 56, Table 29: the original `Catch/index CV` column displayed index standard errors rather than CVs. This scientific documentation error was subsequently verified against the saved input, reader, and model template and corrected only in the `tbl-cv` chunk. See `cv-table-check.json`, `cv-table-before.csv`, and `cv-table-after.csv` for the calculation and comparison exception.

## Page-by-page record

| Page | Content and observation |
|---:|---|
| 36 | Length-composition continuation. Severe vertical wrapping of Year, years, length bins, and multi-digit values; no physical margin clipping. |
| 37 | Same length-table wrapping failure. |
| 38 | Same length-table wrapping failure. |
| 39 | Same length-table wrapping failure. |
| 40 | Same failure; only the final two years occupy the page, leaving extensive blank space. |
| 41 | Completely blank page. |
| 42 | Table 15 caption remains attached. Index numbers in adjacent columns visually touch. Early years contain intentionally absent observations, creating many empty rows. |
| 43 | Table 15 continuation has repeated headers; numeric-column separation remains insufficient. |
| 44 | Tables 16 and 17: readable, contained, captions attached. |
| 45 | Table 18 wraps Southern within the word. Table 19 is clean. Table 20 has tight numeric gutters but remains within margins. |
| 46 | Table 21 start: readable body-mass table, caption attached, no clipping. |
| 47 | Table 21 continuation: repeated headers, readable, no clipping. |
| 48 | Table 22 start: readable body-mass table, caption attached, no clipping. |
| 49 | Table 22 continuation: repeated headers, readable, no clipping. |
| 50 | Table 23 start: readable body-mass table, caption attached, no clipping. |
| 51 | Table 23 continuation: repeated headers, readable, no clipping. |
| 52 | Table 24 start: readable body-mass table, caption attached, no clipping. |
| 53 | Table 24 continuation: repeated headers, readable, no clipping. |
| 54 | Table 25: data coverage is readable and contained. Long year ranges wrap acceptably. |
| 55 | Tables 26 and 27: definitions and equations remain readable and contained. Table 28 starts near the bottom with its caption, header, and several rows together. |
| 56 | Table 28 continuation has repeated headers. Table 29 is visually clean but initially mislabeled index SEs as CVs. Table 30 is readable. Table 31 begins with its caption and several rows attached. |
| 57 | Table 31 final two rows appear without repeated headers. Table 32 is readable. Consider removing the unnecessary page-space gap after these tables. |
| 58 | Table 33 readable overall, but the first column wraps model-group labels within words and over several lines. |
| 59 | Table 34 start: readable, caption attached, contained. Year values incorrectly receive thousands separators, for example 1,970. |
| 60 | Table 34 continuation: repeated headers, no clipping; comma-formatted years persist. |
| 61 | Table 35 start: numbers at age readable, caption attached. Some five-digit cells have tight gutters, without overlap or wrapping. |
| 62 | Table 35 continuation: repeated headers, readable, no clipping. |
| 63 | Table 36 start: numbers at age readable, caption attached, no clipping. |
| 64 | Table 36 continuation: repeated headers, readable, no clipping. |
| 65 | Table 37 start: numbers at age readable, caption attached, no clipping. |
| 66 | Table 37 continuation: repeated headers, readable, no clipping. |
| 67 | Table 38 start: mortality at age readable, caption attached, no clipping. |
| 68 | Table 38 continuation: repeated headers, readable, no clipping. |
| 69 | Table 39 start: mortality at age readable, caption attached, no clipping. |
| 70 | Table 39 continuation: repeated headers, readable, no clipping. |
| 71 | Table 40 start: mortality at age readable, caption attached, no clipping. |
| 72 | Table 40 continuation: repeated headers, readable, no clipping. |
| 73 | Table 41 start: assessment summary readable and contained; caption attached. Literal F_MSY and SSB_MSY headers remain understandable but can be typographically improved. |
| 74 | Table 41 continuation: repeated headers, readable, no clipping. |
| 75 | Table 42 start: assessment summary readable and contained; caption attached. |
| 76 | Table 42 continuation: repeated headers, readable, no clipping. |
| 77 | Table 43 start: assessment summary readable and contained; caption attached. |
| 78 | Table 43 continuation: repeated headers, readable, no clipping. |
| 79 | One short paragraph occupies the page with extensive blank space below; cross-references appear clean. The paragraph could follow the preceding table if pagination allows. |
| 80 | Figure 4 and its caption stay together and are contained. Legend and axis labels are legible. The enlarged raster is visibly soft, but no content is clipped. |

No detached captions or visibly clipped content were found in this page range. The significant layout failures are cell wrapping, numeric-column crowding, and avoidable blank space. Corrected Word output should be rendered and re-inspected because table reflow will alter page boundaries.
