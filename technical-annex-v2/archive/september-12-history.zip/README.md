# Software and methods sources

This folder preserves the report-support package source and the exact projection template behind the saved results. Packaging was completed on 12 September 2026. Packaging preserved the software sources; package installation, package checks and model execution remain separate workflows.

## Report-support package

`jjmR_1.2020.1.tar.gz` is an R source package built from `/Users/jim/_mymods/sprfmo/jjmR` using `R CMD build --no-build-vignettes --no-manual --no-resave-data` against a temporary copy. The original repository was unchanged.

From the Technical Annex v2 folder, a scientist with R and the package's declared dependencies available can install it with:

```sh
R CMD INSTALL software/jjmR_1.2020.1.tar.gz
```

The tarball can also be unpacked for direct access to its `R/`, `man/`, DESCRIPTION and NAMESPACE files. Its 41 R source files match the original source files byte for byte. Local R session files, Git metadata and RStudio state are excluded.

The source repository was at commit `80ca41cd8891e1221dba5c22e034036bde7a6c4f`, with uncommitted changes in `R/jjm.diag-internal.R` and `R/jjm.output-internal.R`. Those changes support labelled yield-profile columns and separate stock-specific yield profiles. They are included in the tarball and retained explicitly in `jjmR-working-tree.patch`; `jjmR-git-status.txt` records the source state.

`jjmR-installed-source-comparison.json` records an independent comparison against the package used to read the portable assessment snapshot. All **273 directly assigned top-level functions** matched the installed namespace in function formals and bodies. Both source and installed version strings are `1.2020.1`; the installed package reports a 10 September 2026 build. The comparison excluded environments, bytecode and source-reference attributes. The comparison covers function definitions; nonfunction constants, namespace registration, documentation, data and dependency versions require separate checks. Version equality alone is insufficient to identify this local package version; retain the tarball hash, source commit and dirty patch together.

`jjmR-source-manifest.json` records source-file hashes, tarball hash, Git revision, build command and status, archive validation, and the code-comparison hash. The broader R/package environment is recorded in `../provenance/R-environment.txt`. The source package build succeeded; installation and clean-environment report rendering remain separate checks.

## Projection methods source

`model-projection/jjm.tpl` was copied exactly from:

```text
/Users/jim/_mymods/sprfmo/jmMSE26/output/jjm-reference-replacement-complete-2026/build/jjm.tpl
```

Its SHA256 is:

```text
b3bef2d3147d967e679140be99d912119061f786c3e0eeea48f11801a31fe7bc
```

This matches `../report/projection-10yr/manifest.json`. It is the corrected template that separates global and projection MSY calculations, applies the future-selectivity convention consistently in scenario 4, and reports the consecutive-year replacement diagnostic. It is provided for source inspection, separate from the original assessment result products under `../data/assessment/`.

`model-projection/` also preserves the original `validate_model.py`, `export_risk.py` and `validate_html.py` sources from the same validation workspace. Their exact hashes and original paths are in `model-projection/source-manifest.json`.

These scripts retain their original workspace assumptions and serve as **historical source evidence**. In particular:

- `validate_model.py` includes executable ADMB projection-window checks in its main program. Packaging retained the script for inspection.
- `export_risk.py` expects the earlier run directory structure, Hessian logs, `.eva`/`.std` files, and saved assessment products. It exports the annual risk/reference records from those completed runs.
- `validate_html.py` checks the original rendered report and its expected values/resources.

The source-only folder preserves the calculation scripts and template; the original validation workspace held additional run products. Reexecuting those historical scripts requires reviewing their paths and input requirements. Ordinary report builds consume the already saved assessment and risk products and require no ADMB execution.
