#!/usr/bin/env python3
"""Render the annex and human handover from the portable saved-product snapshot."""
from argparse import ArgumentParser
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
from scripts.format_docx import format_docx

ROOT = Path(__file__).resolve().parent
parser = ArgumentParser(description=__doc__)
parser.add_argument('--to', choices=['all', 'pdf', 'docx', 'html'], default='all')
parser.add_argument('--document', choices=['all', 'annex', 'guide'], default='all')
args = parser.parse_args()
quarto = shutil.which('quarto')
if not quarto:
    sys.exit('Install Quarto and reopen your terminal, then run python3 build.py again.')
if not (ROOT/'data/assessment/config/h1_1.06.ctl').exists():
    sys.exit('The assessment snapshot is missing. See START-HERE.md and scripts/snapshot_assessment.py.')
formats = ['docx', 'pdf', 'html'] if args.to == 'all' else [args.to]
documents = {'annex': 'technical-annex', 'guide': 'technology-transfer'}
selected = list(documents.values()) if args.document == 'all' else [documents[args.document]]
(ROOT/'output').mkdir(exist_ok=True)
(ROOT/'provenance').mkdir(parents=True, exist_ok=True)
(ROOT/'validation/build-logs').mkdir(parents=True, exist_ok=True)
for document in selected:
    for output_format in formats:
        command = [quarto, 'render', document+'.qmd', '--to', output_format]
        log = ROOT/'validation/build-logs'/f'{document}-{output_format}.log'
        print(f'Creating {document}.{output_format}', flush=True)
        with log.open('w') as stream:
            result = subprocess.run(command, cwd=ROOT/'report', stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            print(log.read_text()[-10000:], file=sys.stderr)
            sys.exit(f'Render failed. Details: {log}')
        output = ROOT/'output'/f'{document}.{output_format}'
        if not output.exists() or output.stat().st_size == 0:
            sys.exit(f'Expected output missing: {output}')
        if output_format == 'docx':
            format_docx(output)
# Supporting files travel beside the HTML. PDF and Word embed the report figures.
for name in ['HCR_2022_Annex_K.pdf', 'projection-10yr']:
    source, target = ROOT/'report'/name, ROOT/'output'/name
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True)
    else:
        shutil.copy2(source, target)
products = [p for p in (ROOT/'output').iterdir() if p.suffix in ('.html','.pdf','.docx')]
manifest = {
    'built_utc': datetime.now(timezone.utc).isoformat(),
    'quarto_version': subprocess.check_output([quarto, '--version'], text=True).strip(),
    'scope': 'Stock assessment; standalone review package',
    'documents_requested': selected,
    'formats_requested': formats,
    'products': [{'file': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                  'sha256': sha256(p.read_bytes()).hexdigest(),
                  'modified_utc': datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat(),
                  'regenerated_this_invocation': p.stem in selected and p.suffix[1:] in formats}
                 for p in sorted(products)],
}
(ROOT/'provenance/release-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('Finished. Open the files in '+str(ROOT/'output'))
