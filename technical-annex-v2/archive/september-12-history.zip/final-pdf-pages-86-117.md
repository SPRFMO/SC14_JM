# PDF second-pass review, pages 86–117

Every page was inspected at 120 dpi. Pages 86–115 show complete tables/figures and captions. The paired two-stock projections on pages 116–117 extend past the bottom of the page; the final source reduces each plot canvas from 8 inches to 3.5 inches. Final output must show both panels and the full caption for each projection figure.

Composition captions and legend symbols were subsequently reconciled with the plotting methods: predictions use lines for age compositions and points for length compositions.
