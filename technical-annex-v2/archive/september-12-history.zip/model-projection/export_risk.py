from pathlib import Path
import csv, hashlib, json, math, shutil, re
from validate_model import read, ROOT, SAVED

out=ROOT/'staged/doc/annex/projection-10yr'
out.mkdir(exist_ok=True)
rows=[]; provenance=[]; reference=[]
labels={1:'1 × F2026',2:'0.75 × F2026',3:'1.25 × F2026',4:'FMSY scenario',5:'TAC scenario (supplied TAC)',6:'F = 0'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for model in ['h1_1.06.ls','h2_1.06.ls']:
    folder=ROOT/'runs'/model
    log=(folder/'hessian.log').read_text()
    assert 'Starting standard error calculations...  done' in log
    assert not re.search(r'\bnan\b|not positive definite|Hessian is not|^Error',log,re.I|re.M)
    eigen=[]
    for line in (folder/'jjm.eva').read_text().splitlines():
        if line.lstrip().startswith('unsorted:'):
            eigen=list(map(float,line.split(':',1)[1].split())); break
    assert eigen and min(eigen)>0
    for line in (folder/'jjm.std').read_text().splitlines()[1:]:
        fields=line.split()
        assert all(math.isfinite(float(x)) for x in fields[-2:]) and float(fields[-1])>=0
    for name in ['model.ctl','start-10yr.par','hessian.log']:
        shutil.copy2(folder/name,out/f'{model}-{name}')
    provenance.append(dict(model=model,control_sha256=sha(folder/'model.ctl'),data_sha256=sha(folder/'1.06.dat'),parameter_sha256=sha(folder/'start-10yr.par'),minimum_hessian_eigenvalue=min(eigen),
        command='./jjm -ind model.ctl -ainp start-10yr.par -phase 5 -maxfn 0 -fut_sel 3 -msy_sel 15 -tac 1674.975',
        note='Ten projection years; unchanged fitted parameters and zero future recruitment deviations; Hessian and all derived standard errors recomputed. No refitting.'))
    for stock in ([1] if model.startswith('h1') else [1,2]):
        d=read(folder/f'For_R_{stock}.rep'); base=model.replace('.ls','')
        bd=read(SAVED/f'{base}_{stock}_R.rep')
        threshold=sum(r[9] for r in bd['msy_mt'] if 2017<=r[0]<=2026)/10
        filename=f'{model}_{stock}_R.rep'; shutil.copy2(folder/f'For_R_{stock}.rep',out/filename)
        for scenario in [6,2,1,3,4,5]:
            biom=d[f'SSB_fut_{scenario}']; catch=d[f'Catch_fut_{scenario}']
            assert [r[0] for r in biom]==list(range(2027,2037))==[r[0] for r in catch]
            for b,c in zip(biom,catch):
                y,mu,sd=b[:3]; assert all(math.isfinite(x) for x in b+c) and sd>0
                prob=50*math.erfc((threshold-mu)/(sd*math.sqrt(2)))
                rows.append(dict(Hypothesis=base[:2],Stock=stock,Scenario_ID=scenario,Scenario=labels[scenario],Year=int(y),SSB_kt=mu,SSB_SE_kt=sd,BMSY_kt=threshold,Probability_above_percent=prob,Catch_kt=c[1]))
for model in ['h1_1.06','h2_1.06','h1_1.06.ls','h2_1.06.ls']:
    for stock in ([1] if model.startswith('h1') else [1,2]):
        d=read(ROOT/'runs'/model/f'For_R_{stock}.rep')
        reference.append(dict(Model=model,Stock=stock,**{k:d[k][0][0] for k in ['Fmsy_global','Bmsy_global','MSY_global','Fmsy_proj','Bmsy_proj','MSY_proj','repl_F','repl_yld','repl_SSB','repl_target_SSB','repl_SSB_residual','repl_status']}))
assert len(rows)==180
for name,data in [('risk-data.csv',rows),('reference-values.csv',reference)]:
    with (out/name).open('w') as f:
        writer=csv.DictWriter(f,fieldnames=data[0].keys());writer.writeheader();writer.writerows(data)
for name in ['model-validation.json']:
    shutil.copy2(ROOT/name,out/name)
manifest=dict(date='2026-09-11',status='PASS',template_sha256=sha(ROOT/'build/jjm.tpl'),runs=provenance,records=len(rows),horizon_years=[2028,2031,2036],
    thresholds='Fixed base 2017-2026 mean annual BMSY; unchanged. Scalar Bmsy_global is reported separately.',
    probability='100 * (1 - Phi((fixed base BMSY - projected SSB)/ADMB SE)); conditional normal approximation, BMSY uncertainty excluded.',
    files={p.name:sha(p) for p in out.iterdir() if p.is_file()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'risk_rows':len(rows),'minimum_hessian_eigenvalues':[x['minimum_hessian_eigenvalue'] for x in provenance],
    'scenario4_h1':[r for r in rows if r['Hypothesis']=='h1' and r['Scenario_ID']==4 and r['Year'] in [2028,2031,2036]]},indent=2))
