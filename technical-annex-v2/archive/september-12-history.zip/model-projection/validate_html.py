from pathlib import Path
import csv, json, runpy, re, contextlib, io, base64
root=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()): q=runpy.run_path(str(root/'validate-annex.py'))
base=q['BASE']; byid=q['byid']
rows=list(csv.DictReader((base/'projection-10yr/risk-data.csv').open()))
refs=list(csv.DictReader((base/'projection-10yr/reference-values.csv').open()))
checked=0; headers=0; restored=0
for a in q['links']:
    href=a.attrs.get('href','')
    if href.startswith('annex_files/figure-html/'):
        imgs=[n for n in a.walk() if n.tag=='img']; assert len(imgs)==1
        src=imgs[0].attrs['src']; assert src.startswith('data:image/png;base64,')
        p=base/href; p.parent.mkdir(exist_ok=True,parents=True)
        p.write_bytes(base64.b64decode(src.split(',',1)[1]));restored+=1
    if href.startswith('projection-10yr/'):
        assert (base/href).exists(), ('missing linked data',href)
def table_rows(container, tag):
    table=next(n for n in container.walk() if n.tag=='table')
    values=[[re.sub(r'\s+',' ',n.text()).strip() for n in tr.children if n.tag==tag] for tr in table.walk() if tr.tag=='tr']
    return [r for r in values if r]
for hyp,stock,tid in [('h1',1,'tbl-risk-h1'),('h2',1,'tbl-risk-h2-south'),('h2',2,'tbl-risk-h2-north')]:
    actual=table_rows(byid[tid],'td'); assert len(actual)==6
    head=table_rows(byid[tid],'th')[0]; assert len(head)==9
    for index,year in [(2,2028),(4,2031),(6,2036)]:
        assert head[index].replace(' ','')==f'P(B>Bmsy)in{year}',head
        headers+=1
    for ar,scenario in zip(actual,[6,2,1,3,4,5]):
        x={int(r['Year']):r for r in rows if r['Hypothesis']==hyp and int(r['Stock'])==stock and int(r['Scenario_ID'])==scenario}
        expected=[x[2027]['Scenario']]
        for year in [2028,2031,2036]:
            prob=float(x[year]['Probability_above_percent'])
            expected += [str(round(float(x[year]['SSB_kt']))),'<1' if prob<1 else '>99' if prob>99 else str(round(prob))]
        expected += [str(round(float(x[y]['Catch_kt']))) for y in [2027,2028]]
        normalize=lambda v:[s.replace(',','').replace(' ','').replace('\xa0','') for s in v]
        assert normalize(ar)==normalize(expected),(tid,ar,expected)
        checked+=8
reference_checks=0
for doc in ['annex.html','reference_points.html']:
    tree=q['Tree']();tree.feed((base/doc).read_text())
    ids={n.attrs['id']:n for n in tree.root.walk() if 'id' in n.attrs}
    actual=table_rows(ids['tbl-reference-scalar'],'td');assert len(actual)==6
    for ar,r in zip(actual,refs):
        expected=[f'{float(r[k]):.4f}' if k.startswith('F') else f'{float(r[k])/1000:.3f}' for k in ['Fmsy_global','Bmsy_global','Fmsy_proj','Bmsy_proj']]
        assert ar[1:]==expected,(doc,ar,expected)
        reference_checks+=4
    for ident in ['fig-reference-pathways','eq-ref-projection-f','eq-annex-k-replacement']:
        assert ident in ids
assert restored==47
for key in ['broken_fragments','missing_cross_reference_rendered_ids','missing_citation_rendered_ids','duplicate_ids','source_files_newer_than_html','unresolved_markers','exposed_source_code_blocks','console_output_blocks','images_without_nonempty_alt']:
    assert not q['qa']['rendered'][key],(key,q['qa']['rendered'][key])
assert all(x['match'] for x in q['qa']['rendered']['status_matches_native'])
assert 'sec-management-1-stock' in byid and 'sec-management-2-stock' in byid
result=dict(status='PASS',risk_display_values=checked,probability_headers=headers,reference_values=reference_checks,
    stock_status_values=15,restored_lightbox_figures=restored,total_figures=q['qa']['rendered']['images'],
    years=[2028,2031,2036],browser_interaction='Not tested',diagram_png_visual_inspection='PASS')
(root/'html-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
