from pathlib import Path
import json, math, hashlib, subprocess, shutil

ROOT = Path(__file__).resolve().parent
SAVED = Path('/Users/jim/_mymods/sprfmo/jjm/assessment/results')

def read(path):
    result = {}; key = None
    for line in path.read_text().splitlines():
        if line.startswith('$'):
            key = line[1:].strip(); result[key] = []
        elif key and line.strip():
            try: result[key].append(list(map(float, line.split())))
            except ValueError: pass
    return result

def par(path):
    result = {}; key = None
    for line in path.read_text().splitlines():
        if line.startswith('# '):
            key = line[2:].strip(':'); result[key] = []
        elif key:
            result[key] += list(map(float, line.split()))
    return {k:v for k,v in result.items() if v}

def maximum(fn):
    lo, hi = .0001, 5.
    ratio = (math.sqrt(5)-1)/2
    a, b = hi-ratio*(hi-lo), lo+ratio*(hi-lo)
    for _ in range(150):
        if fn(a)>fn(b): hi,b=b,a; a=hi-ratio*(hi-lo)
        else: lo,a=a,b; b=lo+ratio*(hi-lo)
    return (lo+hi)/2

def close(actual, expected, tolerance, message):
    assert abs(actual-expected)<tolerance, (message, actual, expected, tolerance)

def stock_checks(model, stock, folder):
    d=read(folder/f'For_R_{stock}.rep'); p=par(folder/'start-10yr.par')
    old=read(SAVED/f'{model}_{stock}_R.rep')
    fleets=range(4) if model.startswith('h1') else ([0,1,3] if stock==1 else [2])
    fa={k:d[f'F_age_{k+1}'][-1][1:] for k in fleets}
    ratio={k:sum(fa[k])/sum(sum(v) for v in fa.values()) for k in fleets}
    mortality=d['M'][0]; ages=len(mortality)
    wm=[a*b for a,b in zip(d['wt_a_pop'][0],d['mature_a'][0])]
    wf={k:d[f'wt_fsh_{k+1}'][-1][1:] for k in fleets}
    annual=next(row for row in d['msy_mt'] if row[0]==2026)
    r0=math.exp(p[f'log_Rzero[{stock}]'][-1]); h=p[f'steepness[{stock}]'][-1]
    b0=annual[10]; alpha=b0*(1-(h-.2)/(.8*h))/r0; beta=(5*h-1)/(4*h*r0)
    recruit=lambda ssb: ssb/(alpha+beta*ssb)
    def rates(f, selectivity):
        ff={k:[f*ratio[k]*v for v in d[selectivity][k]] for k in fleets}
        z=[mortality[a]+sum(ff[k][a] for k in fleets) for a in range(ages)]
        return ff,z
    def biomass(n,z): return sum(n[a]*math.exp(-z[a]*9.5/12)*wm[a] for a in range(ages))
    def catches(n,ff,z):
        return sum(wf[k][a]*n[a]*ff[k][a]*(-math.expm1(-z[a]))/z[a] for k in fleets for a in range(ages))
    def advance(n,z,r):
        nxt=[r]+[n[a]*math.exp(-z[a]) for a in range(ages-1)]
        nxt[-1]+=n[-1]*math.exp(-z[-1])
        return nxt
    def equilibrium(f,selectivity):
        ff,z=rates(f,selectivity); n=[1.]
        for a in range(ages-1): n.append(n[-1]*math.exp(-z[a]))
        n[-1]/=-math.expm1(-z[-1])
        phi=biomass(n,z); req=(phi-alpha)/(beta*phi)
        return phi*req,catches(n,ff,z)*req
    refs={}
    for label,sel in [('global','sel_msy'),('proj','sel_fut')]:
        f=maximum(lambda f:equilibrium(f,sel)[1]); b,y=equilibrium(f,sel)
        close(f,d[f'Fmsy_{label}'][0][0],2e-5,label+' F optimum')
        close(b,d[f'Bmsy_{label}'][0][0],.05,label+' B equilibrium')
        close(y,d[f'MSY_{label}'][0][0],.02,label+' yield equilibrium')
        refs[label]={'Fmsy':f,'Bmsy_kt':b,'MSY_kt':y}
    n=next(row[1:] for row in d['N'] if row[0]==2026)
    z=[mortality[a]+sum(fa[k][a] for k in fleets) for a in range(ages)]
    nstart=advance(n,z,recruit(biomass(n,z)))
    fp=d['Fmsy_proj'][0][0]; ff,z=rates(fp,'sel_fut'); n=nstart[:]
    projection=[]
    for year in range(2027,2037):
        b=biomass(n,z); c=catches(n,ff,z)
        outb=next(row for row in d['SSB_fut_4'] if row[0]==year)[1]
        outc=next(row for row in d['Catch_fut_4'] if row[0]==year)[1]
        close(b,outb,.08,'scenario 4 biomass'); close(c,outc,.02,'scenario 4 catch')
        projection.append({'year':year,'SSB_difference_kt':b-outb,'catch_difference_kt':c-outc})
        n=advance(n,z,recruit(b))
    fr=d['repl_F'][0][0]; ff,z=rates(fr,'sel_fut')
    target=biomass(nstart,z); catch=catches(nstart,ff,z)
    nxt=advance(nstart,z,recruit(target)); nextb=biomass(nxt,z)
    close(target,d['repl_target_SSB'][0][0],.05,'replacement target')
    close(nextb,d['repl_SSB'][0][0],.05,'replacement next biomass')
    close(catch,d['repl_yld'][0][0],.02,'replacement yield')
    status=d['repl_status'][0][0]
    if status==1:
        close(nextb,target,.03,'independent replacement root')
        assert abs(d['repl_SSB_residual'][0][0])<.001
    elif status==-1: assert fr==0 and nextb<target and catch==0
    else: raise AssertionError(('unexpected replacement status',status))
    for key in ['N','M','wt_a_pop','mature_a','msy_mt']+[f'F_age_{k+1}' for k in fleets]:
        assert d[key]==old[key], ('historical block changed',model,stock,key)
    return dict(model=model,stock=stock,references=refs,scenario4=projection,
        replacement=dict(F=fr,catch_kt=catch,target_SSB_kt=target,next_SSB_kt=nextb,status=status),historical_blocks_unchanged=True)

if __name__=='__main__':
    records=[]; parameters=[]; window_tests=[]
    for model in ['h1_1.06','h2_1.06','h1_1.06.ls','h2_1.06.ls']:
        folder=ROOT/'runs'/model
        a,b=par(folder/'start-10yr.par'),par(folder/'jjm.par')
        assert a==b, ('parameters changed',model)
        parameters.append(dict(model=model,values=sum(map(len,a.values())),maximum_change=0))
        for stock in ([1] if model.startswith('h1') else [1,2]):
            records.append(stock_checks(model,stock,folder))
    for model in ['h1_1.06.ls','h2_1.06.ls']:
        for window in [0,15]:
            dest=ROOT/'checks'/f'{model}-fut{window}'; dest.mkdir(exist_ok=True)
            for name in ['model.ctl','1.06.dat','start-10yr.par','jjm']:
                shutil.copy2(ROOT/'runs'/model/name,dest/name)
            cmd=['./jjm','-ind','model.ctl','-ainp','start-10yr.par','-phase','5','-maxfn','0','-nohess','-fut_sel',str(window),'-msy_sel','15','-tac','1674.975']
            with (dest/'run.log').open('w') as log: subprocess.run(cmd,cwd=dest,stdout=log,stderr=log,check=True)
            for stock in ([1] if model.startswith('h1') else [1,2]):
                d=read(dest/f'For_R_{stock}.rep'); ref=read(ROOT/'runs'/model/f'For_R_{stock}.rep')
                for key in ['Fmsy_global','Bmsy_global','MSY_global','sel_msy']:
                    assert d[key]==ref[key], ('global changed with future selectivity',model,window,stock,key)
                if window==15:
                    close(d['Fmsy_proj'][0][0],d['Fmsy_global'][0][0],2e-5,'matching window F')
                    close(d['Bmsy_proj'][0][0],d['Bmsy_global'][0][0],.1,'matching window B')
                window_tests.append(dict(model=model,stock=stock,fut_sel=window,global_invariant=True,Fmsy_proj=d['Fmsy_proj'][0][0]))
    result=dict(status='PASS',parameters=parameters,stock_checks=records,window_tests=window_tests,
        method='Independent Python Baranov, Beverton-Holt, plus-group and golden-section optimization checks using rounded model reports; unchanged historical blocks and parameter values; controlled projection-window runs.',
        template_sha256=hashlib.sha256((ROOT/'build/jjm.tpl').read_bytes()).hexdigest())
    (ROOT/'model-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'stocks':len(records),'window_tests':len(window_tests),'replacement':[r['replacement'] for r in records]},indent=2))
