# Final editorial and scientific-scope review

Reviewed 12 September 2026. Read-only source review of the cumulative Version 2 annex. Sources reviewed were the entrypoint and all included narrative, table and figure QMD files, together with the bibliography, saved projection manifest, risk CSV, reference-value CSV and validation records. This review does not run or change the assessment model.

**Conclusion:** the included content is an assessment annex with cumulative SC13 methods and source-qualified 2026 working results. One projection-vintage sentence needs correction; bibliography cleanup remains. Scientific definitions and the sampled numerical statements agree with the saved ten-year products.

## Actionable findings

1. **Projection provenance wording:** `report/annex_tables.qmd:695` calls the four projection figures “current” and their risk summaries “corresponding”. `report/annex_plots.qmd:404` correctly explains that those figures retain the earlier five-year 2027–2031 outputs, while the risk tables use the later ten-year calculations. Revise the former sentence to identify both vintages. Add “Earlier five-year (2027–2031)” to the four projection figure captions at lines 414, 422, 432 and 442 so each figure carries that distinction when read separately.
2. **Duplicate SC13 citation:** `sprfmo2025annex` and `sc13annex2025` both identify the same SC13 Annex 11 and are both cited. Consolidate the keys while retaining the historical section's page/paragraph locators and the source PDF metadata; otherwise two 2025 bibliography entries result.
3. **Duplicate bibliography field:** `annexk2022` contains two `note` fields. Combine the SCW14/supplied-version qualification and package PDF location in one field. Proposal status is correctly stated throughout the narrative.

## Scope and cumulative content

- The introduction identifies SC13 assessment background, the May 2026 SCW16 benchmark, subsequent assessment development and SC14 working analyses through 11 September. The current Model 1.06 results retain working status pending the agreed Committee record.
- The history section preserves the SC13 model progression, input-composition provenance, age–length keys and offshore sampling, ageing revision, earlier abundance indices, composition weighting and estimation methods. Historical numerical choices are distinguished from current input/control values. The historical annual comparisons are distinguished from analytical retrospective peels.
- No MSE/CMP methods, screening results, candidate-rule recommendations or operating-model material appear in the included narrative, table or figure sources. SCW17 references in assessment progression and captions identify an archived assessment configuration. The cited SCW17 workshop title includes “Management Strategy Evaluation”; its cited passages concern the documented assessment model development. Other MSE/CMP entries remain unused in the bibliography source and therefore do not constitute included report content.
- Exploratory ADNUTS material concerns assessment uncertainty and retains the mixing/ESS failures. It does not claim validated posterior advice.
- The Annex K material retains the supplied 2022 proposal status, coming-year biomass convention and unresolved implementation choices. It does not present an adopted 2026 management procedure or computed operational TAC.

## Scientific and provenance consistency

- Fixed base-model mean annual BMSY for 2017–2026, annual F/FMSY, global fifteen-year scalar references and three-year projection MSY are explicitly distinguished. The 6.869 Mt base target and 6.041 Mt precautionary mean use the same annual averaging basis. The separate scalar projection BMSY remains distinct.
- The risk tables identify 2028, 2031 and 2036, their fixed base-model thresholds and conditional annual normal probabilities. Recruitment periods are consistently 2001–2015 for the single/southern precautionary projections and 1970–2016 for Far North; steepness is 0.65. The reference-point uncertainty exclusion and separation from pathwise/MCMC probabilities are explicit.
- Independently recalculated all 180 risk CSV probabilities using the normal tail; maximum discrepancy was 1.4211e-14 percentage points. The 2028 single-stock scenario-4 example gives 16.998611%, displayed as 17%.
- Scenario 5 is explicitly an archived implementation with realized catches rather than an achieved fixed TAC projection. The stated 2027 values match the risk CSV: 1,491.6 kt for h1; 1,489.38 + 167.27 = 1,656.65 kt for h2, against the supplied 1,674.975 kt input. The later solver correction is excluded from this saved result set.
- Replacement yields and successful status agree with the reference-value CSV. Precautionary values are 1,104.74, 895.474 and 15.743 kt; the native residuals are below 0.001 kt. The older B2028 = B2026 diagnostic is presented as history, separate from the saved B2028 = B2027 calculation.
- Every present file enumerated by the projection manifest matches its recorded SHA-256. Saved assessment parameters, revised projection source version and later executable changes are distinguished in the narrative. Older validation files are expressly described as superseded history; their outdated statements should remain outside the current report narrative.
- Current catch additions, six-index structure, Offshore 2020–2024 weight window and preliminary/partial-year data status are consistently described. This review checks their presentation and saved validation lineage; it does not independently re-estimate the assessment.

## Prose

There are **zero standalone occurrences of “not”** in the entrypoint and its eight included QMD files. One appears inside the unchanged static Annex K diagram (“the saved projection scenarios do not execute this full rule”); it is a useful scientific-scope qualification. The retained working/proposal/exploratory qualifications remain necessary and should be preserved.

Final PDF/Word pagination, citation rendering and full page layout are reviewed separately. The findings above concern the source snapshot before the final correction pass.
