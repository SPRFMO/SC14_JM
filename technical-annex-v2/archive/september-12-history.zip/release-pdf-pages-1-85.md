# Release PDF review: pages 1–85

Reviewed the 117-page release PDF using individual 144-dpi page rasters in `validation/annex-pdf-release/`, displayed at original detail. This review covers every changed page within pages 1–85. It makes no source edits.

**Layout result: pass. Scientific consistency item: the Mohn rho convention discrepancy below remains pending source reconciliation.**

## Coverage

All 32 changed pages were individually inspected: **1, 2, 4, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 39, 48, 52, 55, 57, 59, 61, 63, 65, 73, 75, 76, 77, 78, 79, 80, 83, 84, 85**.

The other 53 pages within this range match the previously inspected page images exactly according to `validation/release-pdf-image-comparison.json`: **3, 5, 6, 7, 8, 9, 10, 11, 13, 23–38, 40–47, 49–51, 53–54, 56, 58, 60, 62, 64, 66–72, 74, 81–82**. Prior inspection therefore carries forward for these pages. Pages 86–117 are assigned to the lead reviewer.

## Findings by page

| Pages | Result |
|---|---|
| 1–2 | Title and contents are legible. The last contents entries continue on page 2 above the introduction without overlap. Assessment status and historical source distinctions remain readable. |
| 4 | Current assessment data and benchmark/provisional status prose fits within margins. |
| 12 | Equation 8 now places the two catch definitions on separate gathered lines, with clear spacing before the equation number. Equations 7 and 9 and Table 4 also fit. |
| 14–15 | Risk table columns fit, including five-digit biomass values. Table 7 continues with a repeated header; Tables 8 and 9 fit with complete captions and values. No number wrapping or clipping. The retrospective prose on page 15 raises the consistency item below. |
| 16–20 | Sensitivity, uncertainty, assessment SRR, governance/history prose and static diagram fit. Native equations on page 20 have complete terms, labels and spacing. |
| 21–22 | References remain legible and the duplicate SC13 entry has been removed. The last reference on page 22 is complete. |
| 39 | Tables 20–22 retain native data and headings, complete columns and the clarified ageing-error caption. |
| 48 | The input inventory table has adequate width for source labels and year ranges. |
| 52 | Model-comparison table fits, including model labels with trailing zeros and all numeric columns. |
| 55, 57, 59 | Abundance-at-age tables have complete captions specifying millions of fish, stock/model identity, legible column headings and fully visible numeric cells. |
| 61, 63, 65 | Fishing mortality tables specify per-year units and stock/model identity; all columns and displayed rows fit. |
| 73 | The prose distinguishes earlier five-year projection figures from updated ten-year risk summaries and links to the correct figure/table groups. The intentionally sparse transition page has complete text. |
| 75–77 | Retrospective figures, legends, uncertainty bands and revised unit/caption descriptions are visible. The displayed SSB rho values differ from the page 15 prose as detailed below. |
| 78 | Figure 9 now has clear space between its full caption and the page footer. Both stock panels, axes, legends and caption are complete. |
| 79 | Figure 10 title and caption correctly identify total biomass, with kt/thousand-tonne units. All three archived/current configuration legend entries and data traces are visible. |
| 80 | Recruitment comparison caption specifies millions of fish and all configuration labels remain legible. |
| 83–85 | Observed bars and predicted-line legend symbols agree with the plotted age compositions. Panel years, age axes, figure captions and model identities are complete and unclipped. |

## Scientific consistency item requiring closure

Page 15 reports five-peel spawning-biomass Mohn rho values of **0.09 for h1**, **0.30 for the southern stock**, and **0.01 for the far-north stock**. Figure 6 on page 75 labels h1 rho **0.26**; Figure 8 on page 77 labels the southern and far-north values **0.43** and **−0.0086**. These values need an explicit convention explanation or reconciliation so the prose and figures can be interpreted together.

The lead reviewer was notified immediately and assigned an independent source trace. A possible distinction is fitted terminal-year calculations in the summary versus the additional forecast-year endpoint in the saved SSB series used by the package plotting function; this explanation is a hypothesis at this review stage, not a verified conclusion. No values were altered during visual review.

No other new layout defect or scientific-caption inconsistency was found in the assigned changed pages. The prior equation-spacing, risk-column width, abundance-unit, total-biomass-title, Figure 9 footer and predicted-symbol issues are visually resolved in this release snapshot.
