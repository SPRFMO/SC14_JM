# PDF release-layout review, pages 86–117

The 13 changed pages were inspected individually at 120 dpi: pages 86–94 and 114–117. Pages 95–113 are image-identical to the previously reviewed version. All figures, panel labels, legends and complete captions fit the page.

The two-stock projection figures on pages 116–117 each contain both panels and the complete caption within the page margins. This resolves the earlier overflow. Age-fit predictions use line keys; length-fit predictions use point keys and matching captions.

A subsequent narrow update concerns the SSB rho prose and earlier retrospective captions. Final raster comparison establishes whether these pages remain identical.
