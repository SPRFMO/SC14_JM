# Release Word layout review: pages 1–72

Result: **pass; no remaining layout defects found in the reviewed pages.** Sources remained frozen throughout this review.

The final Word conversion has 107 pages. Each of the 23 changed pages in this range was viewed individually at original detail:

3, 4, 13, 16, 17, 18, 20, 21, 22, 23, 40, 49, 53, 56, 58, 59, 60, 61, 62, 64, 65, 66, 67.

The remaining 49 pages through page 72 match their previously reviewed PNGs exactly. Their byte-level SHA256 equality was independently rechecked against `annex-word-final`, consistent with `release-word-image-comparison.json`.

| Pages | Review result |
|---|---|
| 3–4 | Introduction, assessment-history table and body text fit; no clipped text or isolated headings. |
| 13 | Harvest-control-rule diagram and caption remain together; equations and labels are legible. |
| 16–17 | All three risk tables fit. Five-digit biomass values, including 10,880, 14,110, 10,944 and 13,275, remain on one line. Probability labels, years and catch headings fit. All rows and captions are present. Numeric results align right. |
| 18 | SRR/reference-point diagram, explanatory text and caption fit and remain associated. |
| 20–23 | Historical methods, equations and references fit. Equation numbers and mathematical symbols are complete; URLs wrap within the page. |
| 40 | Maturity and growth tables fit. The complete 12-by-12 ageing-error matrix is visible. Its caption explicitly identifies observed ages as rows and true ages as columns and notes that the current assessment disables ageing error. |
| 49 | Coverage table is legible. Peru_Artis_CPUE and other source names fit on one line; year ranges wrap at sensible boundaries. Caption and complete table remain on the same page. |
| 53 | Model register fits on one page. Model 0.00, 0.10 and 1.00 retain their intended display labels; 1.xx.ls remains intact. The group label wraps at the space after Models. Descriptions and caption are complete. |
| 56, 58–62, 64–67 | Wide numerical tables fit with all age columns and years visible. Values retain their digits and commas. Headers repeat on continuation pages, and rows remain intact. Captions stay with table starts. |

Numerical alignment was also checked using cropped views of pages 40, 61, 65 and 67. For page 65, PDF text coordinates independently confirm equal 37.05-point spacing between the right edges of every age-column value in the 2007 row. The apparent crowding in some full-page previews is absent from the actual rendered positions.

No clipping, table overflow, split numerical strings, detached captions or missing continuation headers were found. This record covers only pages 1–72; pages 73–107 are assigned separately.
