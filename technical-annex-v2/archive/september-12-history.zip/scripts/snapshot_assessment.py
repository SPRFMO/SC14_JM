#!/usr/bin/env python3
"""Snapshot the saved JJM assessment products used by Technical Annex v2.

Example:
  python3 scripts/snapshot_assessment.py --jjm /path/to/jjm \
    --destination data/assessment

Requires Python 3, Rscript, and the report's installed R packages. No ADMB
executable is invoked. Existing snapshots are refused unless --replace is
explicit; replacement preserves the previous snapshot and metadata as backups.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


MODELS = ("h1_1.06", "h2_1.06", "h1_1.06.ls", "h2_1.06.ls")
SAVED_OBJECTS = (
    "h1_1.06_retrospective.RData", "h2_1.06_retrospective.RData",
    "mod_preBM_h1.Rdat", "mod_prev_h1.Rdat",
)

R_CHECK = r'''
args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(args[[1]], mustWork=TRUE)
setwd(root)
cat("Saved-product rendering environment\n")
cat("Recorded UTC:", format(Sys.time(), tz="UTC", usetz=TRUE), "\n")
cat("R version:", R.version.string, "\n")
cat("Platform:", R.version$platform, "\n")
cat("R libraries:", paste(.libPaths(), collapse="; "), "\n")
packages <- c("jjmR", "tidyverse", "flextable", "knitr", "scales",
              "kableExtra", "rmarkdown", "officer", "ggplot2", "ragg",
              "systemfonts", "tinytex")
required <- c("jjmR", "tidyverse", "flextable", "knitr", "scales", "rmarkdown")
for (p in packages) {
  available <- requireNamespace(p, quietly=TRUE)
  if (!available && p %in% required) stop("Required package missing: ", p)
  cat("PACKAGE", p, if (available) as.character(packageVersion(p)) else "NOT INSTALLED (optional)", "\n")
}
cat("JJMR DESCRIPTION\n")
print(packageDescription("jjmR")[c("Package", "Version", "Built",
      "RemoteType", "RemoteRepo", "RemoteUsername", "RemoteSha")])
.annex_reads <- character()
ns <- asNamespace("jjmR")
helpers <- c(".getCtlFile", ".getDatFile", ".getYldFile", ".getParFile", ".getRepFiles")
for (f in helpers) trace(f, where=ns, print=FALSE,
  exit=quote(.GlobalEnv$.annex_reads <- c(.GlobalEnv$.annex_reads, returnValue())))
for (m in c("h1_1.06", "h2_1.06", "h1_1.06.ls", "h2_1.06.ls")) {
  z <- jjmR::readJJM(m, path="config", input="input", output="results")
  expected <- if (startsWith(m, "h1")) 1L else 2L
  stopifnot(length(z[[1]]$output)==expected,
            identical(as.numeric(z[[1]]$data$years), c(1970,2026)),
            all(vapply(z[[1]]$output, function(x) ncol(x$msy_mt)==13L, logical(1))))
  cat("MODEL_READ_PASS", m, "stocks", length(z[[1]]$output), "\n")
}
for (f in helpers) untrace(f, where=ns)
for (p in sort(unique(.annex_reads))) {
  p <- normalizePath(p, mustWork=TRUE)
  stopifnot(startsWith(p, paste0(root, "/")))
  cat("READJJM_INPUT", substring(p, nchar(root)+2L), "\n")
}
objects <- c("h1_1.06_retrospective.RData", "h2_1.06_retrospective.RData",
             "mod_preBM_h1.Rdat", "mod_prev_h1.Rdat")
for (f in objects) {
  e <- new.env(parent=baseenv())
  n <- load(file.path("results",f), envir=e)
  expected <- if (grepl("retrospective",f)) "output" else sub(".Rdat$", "",f)
  stopifnot(expected %in% n)
  cat("SAVED_OBJECT_PASS", f, "objects", paste(n,collapse=","), "\n")
}
register <- read.csv("data/SC14_runs.csv",check.names=FALSE)
stopifnot(nrow(register)>0)
cat("RUN_REGISTER_PASS", nrow(register), "rows\n")
cat("SESSION_INFO\n")
print(sessionInfo())
cat("No model executable or refit was invoked.\n")
'''


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def control_value(path: Path, field: str) -> str:
    lines = path.read_text().splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "#" + field:
            for following in lines[i + 1:]:
                value = following.split("#", 1)[0].strip()
                if value:
                    return value.split()[0]
    raise ValueError(f"Missing control field {field}: {path}")


def command_output(command: list[str]) -> str | None:
    result = subprocess.run(command, capture_output=True, text=True)
    return result.stdout.strip() if result.returncode == 0 else None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jjm", type=Path, required=True, help="Source JJM repository root")
    parser.add_argument("--destination", type=Path, required=True, help="Snapshot assessment directory")
    parser.add_argument("--rscript", default="Rscript", help="Rscript executable")
    parser.add_argument("--environment-file", type=Path,
                        help="Defaults to DESTINATION/../../provenance/R-environment.txt")
    parser.add_argument("--replace", action="store_true",
                        help="Preserve existing snapshot/metadata as timestamped backups and replace")
    args = parser.parse_args()
    repository = args.jjm.expanduser().resolve(strict=True)
    source = (repository / "assessment").resolve(strict=True)
    destination = args.destination.expanduser().resolve()
    if source == destination or source in destination.parents or destination in source.parents:
        parser.error("Destination and original assessment must be separate directory trees")
    manifest_path = destination.parent / "assessment-source-manifest.json"
    environment_path = (args.environment_file or
                        destination.parent.parent / "provenance/R-environment.txt").expanduser().resolve()
    managed_targets = (destination, manifest_path, environment_path)
    if any(target == repository or repository in target.parents for target in managed_targets):
        parser.error("Snapshot outputs must be outside the original JJM repository")
    existing = [str(p) for p in managed_targets if p.exists()]
    if existing and not args.replace:
        parser.error("Existing output refused; use --replace explicitly: " + "; ".join(existing))
    if shutil.which(args.rscript) is None:
        parser.error("Rscript is required to validate the saved snapshot")

    relative_files: set[Path] = set()
    model_records = []
    for model in MODELS:
        control = Path("config") / f"{model}.ctl"
        data_name = control_value(source / control, "dataFile")
        if Path(data_name).is_absolute() or ".." in Path(data_name).parts:
            parser.error(f"Nonportable dataFile in {control}: {data_name}")
        data = Path("input") / data_name
        stocks = int(control_value(source / control, "nStocks"))
        if control_value(source / control, "modelName") != model:
            parser.error(f"Unexpected modelName in {control}")
        required = [control, data, Path("results") / f"{model}.par",
                    Path("results") / f"{model}.yld"]
        required.extend(Path("results") / f"{model}_{s}_R.rep" for s in range(1, stocks + 1))
        relative_files.update(required)
        model_records.append({"model": model, "stocks": stocks,
                              "files": [str(p) for p in required]})
    relative_files.update(Path("results") / f for f in SAVED_OBJECTS)
    relative_files.add(Path("data/SC14_runs.csv"))
    missing = [str(source / p) for p in sorted(relative_files) if not (source / p).is_file()]
    if missing:
        parser.error("Required saved products are missing: " + "; ".join(missing))

    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=f".{destination.name}-staging-", dir=destination.parent))
    try:
        records = []
        for relative in sorted(relative_files):
            original = source / relative
            target = stage / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            before = digest(original)
            shutil.copy2(original, target)
            after = digest(original)
            if before != after or before != digest(target):
                raise RuntimeError(f"Source changed during copy or copy hash differs: {original}")
            records.append({"path": str(relative), "source": str(original),
                            "bytes": target.stat().st_size, "sha256": before})
        # Match the report's configured package libraries while preventing
        # restoration or saving of an analyst's workspace.
        check = subprocess.run([args.rscript, "--no-save", "--no-restore", "-", str(stage)],
                               input=R_CHECK, capture_output=True, text=True)
        if check.returncode:
            raise RuntimeError("Saved-product validation failed:\n" + check.stdout + check.stderr)
        now = datetime.now(timezone.utc)
        stamp = now.strftime("%Y%m%dT%H%M%S%fZ")
        environment = (check.stdout + "\nR STDERR (including package startup messages):\n" + check.stderr)
        environment = environment.replace(str(stage), str(destination))
        source_state = command_output(["git", "-C", str(repository), "rev-parse", "HEAD"])
        status = command_output(["git", "-C", str(repository), "status", "--porcelain", "--"] +
                                [str((source / p).relative_to(repository)) for p in sorted(relative_files)])
        read_paths = sorted(line.removeprefix("READJJM_INPUT ").strip()
                            for line in check.stdout.splitlines() if line.startswith("READJJM_INPUT "))
        manifest = {
            "schema_version": 1, "created_utc": now.isoformat(),
            "purpose": "Saved assessment inputs/products for Technical Annex v2 rendering; no refitting",
            "source_jjm": str(repository), "source_git_head": source_state,
            "source_selected_file_git_status": status,
            "destination": str(destination), "models": model_records,
            "files": records, "file_count": len(records),
            "total_bytes": sum(r["bytes"] for r in records),
            "readjjm_helper_trace": read_paths,
            "validation": {"status": "PASS", "models_loaded": list(MODELS),
                           "saved_objects_loaded": list(SAVED_OBJECTS),
                           "original_and_copy_sha256_equal": True,
                           "model_runs_performed": False},
            "r_environment": str(environment_path),
            "r_environment_sha256": hashlib.sha256(environment.encode()).hexdigest(),
            "distinctions": [
                "Original five-year .ls products are retained for existing projection diagnostics.",
                "Corrected ten-year risk products are separate under report/projection-10yr.",
                "Historical Rdat files already contain model objects; archived input trees are not required.",
                "A successful saved-product read verifies build inputs, not scientific acceptance or convergence."
            ],
        }
        for target in managed_targets:
            if target.exists():
                target.rename(target.with_name(target.name + ".backup-" + stamp))
        stage.rename(destination)
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        environment_path.parent.mkdir(parents=True, exist_ok=True)
        environment_path.write_text(environment)
        print(f"Saved-product snapshot verified: {len(records)} files, {manifest['total_bytes']} bytes")
        print(f"Assessment: {destination}\nManifest: {manifest_path}\nEnvironment: {environment_path}")
    finally:
        if stage.exists():
            shutil.rmtree(stage)


if __name__ == "__main__":
    main()
