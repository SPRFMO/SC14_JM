"""Apply repeatable page-fit and table-row settings to Quarto's Word output."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import xml.etree.ElementTree as ET

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
NS = {'w': W, 'wp': WP, 'a': A}


def format_docx(path):
    path = Path(path)
    with ZipFile(path) as archive:
        members = {name: archive.read(name) for name in archive.namelist()}
    root = ET.fromstring(members['word/document.xml'])
    for table in root.findall('.//w:tbl', NS):
        properties = table.find('w:tblPr', NS)
        if properties is None:
            properties = ET.Element(f'{{{W}}}tblPr'); table.insert(0, properties)
        borders = properties.find('w:tblBorders', NS)
        if borders is None:
            borders = ET.SubElement(properties, f'{{{W}}}tblBorders')
        for side in ['top','left','bottom','right','insideH','insideV']:
            border = borders.find(f'w:{side}', NS)
            if border is None: border = ET.SubElement(borders, f'{{{W}}}{side}')
            for key,value in [('val','single'),('sz','4'),('color','D9D9D9')]:
                border.set(f'{{{W}}}{key}',value)
        for row in table.findall('w:tr', NS):
            properties = row.find('w:trPr', NS)
            if properties is None:
                properties = ET.Element(f'{{{W}}}trPr'); row.insert(0,properties)
            if properties.find('w:cantSplit', NS) is None:
                ET.SubElement(properties,f'{{{W}}}cantSplit')
    # Tall multi-panel plots retain their aspect ratio and leave room for captions.
    for drawing in root.findall('.//wp:inline', NS):
        extent = drawing.find('wp:extent', NS)
        if extent is None: continue
        cx, cy = int(extent.get('cx')), int(extent.get('cy'))
        scale = min(1, 6.3*914400/cx, 8*914400/cy)
        if scale < 1:
            new_x,new_y = str(round(cx*scale)),str(round(cy*scale))
            extent.set('cx',new_x);extent.set('cy',new_y)
            for inner in drawing.findall('.//a:xfrm/a:ext',NS):
                inner.set('cx',new_x);inner.set('cy',new_y)
    members['word/document.xml'] = ET.tostring(root,encoding='utf-8',xml_declaration=True)
    temporary = path.with_suffix('.formatted.docx')
    with ZipFile(temporary,'w',ZIP_DEFLATED) as archive:
        for name,data in members.items(): archive.writestr(name,data)
    temporary.replace(path)
