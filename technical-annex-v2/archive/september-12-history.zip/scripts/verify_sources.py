#!/usr/bin/env python3
"""Check the saved inputs and frozen sources using only Python's standard library.

Run from the transferred folder with: python3 scripts/verify_sources.py
Original absolute paths in the manifests are provenance; only bundled relative
paths are read. This checks file identity and performs no model or report runs.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sys
import tarfile


FROZEN_TEMPLATE_SHA256 = "b3bef2d3147d967e679140be99d912119061f786c3e0eeea48f11801a31fe7bc"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class Verification:
    def __init__(self, root):
        self.root = root.resolve()
        self.errors = []

    def path(self, relative):
        relative = Path(relative)
        if relative.is_absolute():
            raise ValueError("Expected a bundled relative path: " + str(relative))
        path = (self.root / relative).resolve()
        if self.root not in path.parents:
            raise ValueError("Path leaves the transferred folder: " + str(relative))
        return path

    def manifest(self, relative):
        return json.loads(self.path(relative).read_text(encoding="utf-8"))

    def check_file(self, relative, expected, size=None):
        path = self.path(relative)
        if not path.is_file():
            self.errors.append("Missing: " + str(relative))
            return
        if size is not None and path.stat().st_size != size:
            self.errors.append("Size differs: " + str(relative))
        if sha256(path) != expected:
            self.errors.append("SHA256 differs: " + str(relative))

    def records(self, base, records, path_key="path"):
        names = [record[path_key] for record in records]
        if len(names) != len(set(names)):
            raise ValueError("Duplicate file entries: " + str(base))
        for record in records:
            self.check_file(Path(base) / record[path_key], record["sha256"],
                            record.get("bytes"))

    def group(self, label, operation):
        before = len(self.errors)
        detail = ""
        try:
            detail = operation()
        except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
            self.errors.append(label + ": " + str(error))
        if len(self.errors) == before:
            print("PASS " + label + (": " + detail if detail else ""))
        else:
            print("FAIL " + label)

    def assessment(self):
        manifest = self.manifest("data/assessment-source-manifest.json")
        records = manifest["files"]
        if len(records) != 24 or manifest["file_count"] != len(records):
            raise ValueError("This release requires 24 assessment files")
        self.records("data/assessment", records)
        return "24 saved input/result files"

    def projection(self):
        manifest = self.manifest("report/projection-10yr/manifest.json")
        records = [{"path": name, "sha256": value}
                   for name, value in manifest["files"].items()]
        if len(records) != 13:
            raise ValueError("This release requires 13 projection files")
        self.records("report/projection-10yr", records)
        return "13 saved projection files"

    def model_sources(self):
        manifest = self.manifest("software/model-projection/source-manifest.json")
        projection = self.manifest("report/projection-10yr/manifest.json")
        if any(value != FROZEN_TEMPLATE_SHA256 for value in (
                manifest["template_sha256"], projection["template_sha256"])):
            raise ValueError("Projection manifests differ from the frozen template hash")
        self.records("software/model-projection", manifest["files"])
        self.check_file("software/model-projection/jjm.tpl", FROZEN_TEMPLATE_SHA256)
        return "frozen template and 3 preserved export/validation scripts"

    def package_source(self):
        manifest = self.manifest("software/jjmR-source-manifest.json")
        archive_path = Path("software") / manifest["source_tarball"]
        self.check_file(archive_path, manifest["source_tarball_sha256"],
                        manifest["source_tarball_bytes"])
        for key in ("dirty_patch", "installed_source_comparison"):
            self.check_file(Path("software") / manifest[key], manifest[key + "_sha256"])
        source_records = {record["path"]: record for record in manifest["source_files"]
                          if record["path"].startswith("R/") and record["path"].endswith(".R")}
        if len(source_records) != 41:
            raise ValueError("This release requires 41 R source files")
        with tarfile.open(self.path(archive_path), "r:gz") as archive:
            members = [member for member in archive.getmembers() if member.isfile()]
            if len(members) != manifest["tarball_file_count"]:
                raise ValueError("Source archive file count differs")
            r_members = {member.name[len("jjmR/"):]: member for member in members
                         if member.name.startswith("jjmR/R/") and member.name.endswith(".R")}
            if set(r_members) != set(source_records):
                raise ValueError("Source archive R file inventory differs")
            for name, member in r_members.items():
                with archive.extractfile(member) as stream:
                    data = stream.read()
                record = source_records[name]
                if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
                    self.errors.append("Source archive member differs: " + name)
        return "archive, 41 R source members, dirty patch and saved comparison record"

    def inherited_sources(self):
        records = self.manifest("provenance/inherited-source-manifest.json")
        if not records:
            raise ValueError("Inherited source manifest is empty")
        self.records(".", records, path_key="snapshot")
        return str(len(records)) + " inherited source files, including the SC13 PDF"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1],
                        help="Transferred report folder (default: parent of this script's folder)")
    args = parser.parse_args()
    check = Verification(args.root)
    for label, operation in (
            ("Assessment", check.assessment),
            ("Projections", check.projection),
            ("Model sources", check.model_sources),
            ("jjmR source archive", check.package_source),
            ("Inherited sources", check.inherited_sources)):
        check.group(label, operation)
    if check.errors:
        for error in check.errors:
            print("  " + error, file=sys.stderr)
        print("FAIL: " + str(len(check.errors)) + " source verification issue(s).")
        return 1
    print("PASS: bundled files match their recorded hashes; no models were executed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
