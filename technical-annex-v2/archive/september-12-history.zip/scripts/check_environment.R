packages <- c("jjmR", "tidyverse", "flextable", "knitr", "scales", "rmarkdown")
cat(R.version.string, "\n")
present <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
for (p in packages) {
  cat(p, if (present[[p]]) as.character(packageVersion(p)) else "MISSING", "\n")
}
if (any(!present)) {
  stop("Install the missing packages shown above, then run this check again.", call. = FALSE)
}
cat("Report packages are available.\n")
