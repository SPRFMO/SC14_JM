if (getRversion() >= "2.15.1") {
  utils::globalVariables(c(
    ".data", "V1", "V2", "acf", "age", "age_lab", "assessmenttype",
    "assessmentyear", "asymptote", "b_bmsy", "b_bmsy_diff", "b_bmsy_end",
    "bbmsy", "bio", "biomass", "bmsy", "break_year", "catch",
    "classing", "cohort", "cols", "cv", "denom", "dev", "dynamic_bmsy",
    "est", "f", "f_fmsy", "f_fmsy_diff", "f_fmsy_end", "ffmsy", "fill",
    "fleet", "fleet_number", "fleet_type", "fmsy", "fpr", "francis_n",
    "hyp", "index", "input_n", "label", "lag", "log_ratio", "log_resid",
    "lower", "mean_cv", "model", "mods_comb", "name", "num", "object",
    "obs", "obs_p", "obs_prop", "peel", "pred", "pred_p", "pred_prop",
    "prop", "proportion", "q", "q_break", "q_power", "r", "ratio",
    "resid", "rmse", "rowid", "scenario", "sd", "sdnr", "sel",
    "selectivity", "series", "series2", "seriesnr", "size_s", "source",
    "ssb", "ssb_dir", "std_resid", "stock", "stocks", "survey",
    "things", "tpr", "tyear", "type", "upper", "value", "var", "weight",
    "xmax", "xmin", "y", "year", "ymax", "ymin"
  ))
}
