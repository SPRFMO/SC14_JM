#!/usr/bin/env python3
"""Validate the reporting-only 100-draw evaluation and its stock-F ratio."""
from pathlib import Path
from collections import Counter, defaultdict
import csv, hashlib, json, math, struct

root = Path(__file__).resolve().parent
source_root = root.parent
provenance_path = root / 'derivation-provenance.json'
p = json.loads(provenance_path.read_text())
assert p['evaluation_exit_code'] == 0
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(source_root / 'source/jjm2.tpl') == p['original_template_sha256']
assert sha(root / 'jjm2.tpl') == p['reporting_template_sha256']
for name, digest in p['input_sha256'].items():
    assert sha(source_root / 'prepared' / name) == digest, name
rows = list(csv.DictReader((root / 'selection-manifest.csv').open()))
selected = [int(row['pooled_draw']) for row in rows]
pooled = (source_root / 'run/jjm2.psv').read_bytes()
subset = (root / 'jjm2.psv').read_bytes()
assert sha(source_root / 'run/jjm2.psv') == p['pooled_psv_sha256']
block = p['psv_format']['bytes_per_draw']
assert subset[:4] == pooled[:4] and len(subset) == 4 + 100 * block
assert all(subset[4+i*block:4+(i+1)*block] == pooled[4+(j-1)*block:4+j*block]
           for i,j in enumerate(selected))
counts = Counter()
yearly = {}
faa = defaultdict(list)
records = 0
with (root / 'mceval.rep').open() as file:
    assert file.readline().strip() == 'mcdraw type Year Age value'
    for line in file:
        parts = line.split()
        assert len(parts) == 6, parts
        draw, kind, unit, year, age, raw = parts
        draw = int(draw)
        value = float(raw)
        assert 1 <= draw <= 100 and math.isfinite(value)
        counts[kind] += 1
        records += 1
        if kind in ('SSB', 'SBMSYy', 'FMSYy', 'FFMSYy'):
            assert unit == '1' and age == 'all'
            key = draw, int(year), kind
            assert key not in yearly, key
            yearly[key] = value
        elif kind == 'F_faa':
            faa[draw, int(year)].append((int(unit), int(age), value))
assert records == 100 * (13768 + 2 * 57)
assert counts['FMSYy'] == counts['FFMSYy'] == 5700
assert len(yearly) == 4 * 5700
errors = []
for draw in range(1, 101):
    for year in range(1970, 2027):
        frows = faa[draw, year]
        # Four fleets, 12 model ages; mean over ages in each fleet, then sum.
        assert len(frows) == 48
        assert {(fleet, age) for fleet, age, _ in frows} == {
            (fleet, age) for fleet in range(1, 5) for age in range(1, 13)}
        stock_f = sum(v for _, _, v in frows) / 12
        fmsy = yearly[draw, year, 'FMSYy']
        ratio = yearly[draw, year, 'FFMSYy']
        assert fmsy > 0 and ratio >= 0
        reconstructed = stock_f / (fmsy + 1e-10)
        err = abs(ratio - reconstructed)
        relative = err / max(abs(ratio), abs(reconstructed), 1e-30)
        # Native mceval values have six significant digits; allow their rounding.
        assert math.isclose(ratio, reconstructed, rel_tol=2e-5, abs_tol=2e-8), (draw, year, ratio, reconstructed)
        errors.append((err, relative))
p['status'] = 'complete; source, PSV mapping, schema and stock-F ratio checks passed'
p['native_output_sha256'] = sha(root / 'mceval.rep')
p['native_output_bytes'] = (root / 'mceval.rep').stat().st_size
p['native_records'] = records
p['records_by_type'] = dict(sorted(counts.items()))
p['new_fields_verified_draw_years'] = 5700
p['stock_f_ratio_check'] = {
    'reconstruction': 'sum of four fleets mean-age F_faa / (FMSYy + 1e-10); 12 ages per fleet',
    'draw_years': 5700,
    'max_absolute_difference': max(x[0] for x in errors),
    'max_relative_difference': max(x[1] for x in errors),
    'relative_tolerance': 2e-5,
    'absolute_tolerance': 2e-8,
    'tolerance_reason': 'Native reported F_faa, FMSYy and FFMSYy have six significant digits.',
    'result': 'pass'}
p['canonical_files_rechecked'] = 'Frozen template, all five prepared data/control/parameter files, and pooled PSV retain their recorded hashes.'
provenance_path.write_text(json.dumps(p, indent=2) + '\n')
print(json.dumps({key: p[key] for key in ['status', 'evaluation_exit_code', 'evaluation_wall_seconds', 'native_output_bytes', 'native_records', 'stock_f_ratio_check']}, indent=2))
