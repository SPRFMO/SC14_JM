#!/usr/bin/env python3
"""Re-evaluate the archived 100-draw subset with two reporting-only fields."""
from pathlib import Path
import argparse, csv, datetime, hashlib, json, shutil, struct, subprocess, sys, time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('run_root', type=Path, help='Fresh reproduction root with frozen source, prepared files and archived pooled PSV')
parser.add_argument('--admb', default='admb', help='ADMB 13.2 command; an absolute path is recommended')
parser.add_argument('--stage-only', action='store_true', help='Stage and verify inputs without compiling or evaluating')
args = parser.parse_args()
package = Path(__file__).resolve().parent
root = args.run_root.resolve(strict=True)
out = root / 'kobe-evaluation'
if out.exists():
    raise SystemExit('Refusing to overwrite existing kobe-evaluation; use a fresh reproduction root.')
original_provenance = package / 'derivation-provenance.json'
p = json.loads(original_provenance.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = root / 'source/jjm2.tpl'
assert sha(source) == p['original_template_sha256'], 'Frozen template differs from original run'
for name, digest in p['input_sha256'].items():
    assert sha(root / 'prepared' / name) == digest, 'Prepared file differs: ' + name
pooled_path = root / 'run/jjm2.psv'
assert sha(pooled_path) == p['pooled_psv_sha256'], 'Requires the original archived pooled PSV'
rows = list(csv.DictReader((package / 'selection-manifest.csv').open()))
assert len(rows) == 100
assert [int(row['evaluation_draw_id']) for row in rows] == list(range(1,101))
selected = [int(row['pooled_draw']) for row in rows]
assert len(set(selected)) == 100 and min(selected) >= 1 and max(selected) <= 3000
patch = (package / 'reporting-only.patch').read_text()
additions = [line[1:] for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++')]
removals = [line for line in patch.splitlines() if line.startswith('-') and not line.startswith('---')]
assert len(additions) == 2 and not removals
anchor = '    mceval<< mc_count<<" SBMSYy  "<<k<<" "<<i<<" all "<<Bmsy(k)<<  endl;\n'
text = source.read_text()
assert text.count(anchor) == 1
patched = text.replace(anchor, anchor + '\n'.join(additions) + '\n')
assert hashlib.sha256(patched.encode()).hexdigest() == p['reporting_template_sha256']
pooled = pooled_path.read_bytes()
assert sys.byteorder == p['psv_format']['native_byteorder'], 'PSV is in the original native byte order'
npar = struct.unpack('=i', pooled[:4])[0]
assert npar == 1593
block = npar * 8
assert len(pooled) == 4 + 3000 * block
subset = pooled[:4] + b''.join(pooled[4+(i-1)*block:4+i*block] for i in selected)
assert hashlib.sha256(subset).hexdigest() == p['subset_psv_sha256']
out.mkdir()
shutil.copy2(source, out / 'jjm2-original.tpl')
(out / 'jjm2.tpl').write_text(patched)
(out / 'jjm2.psv').write_bytes(subset)
for name in p['input_sha256']:
    shutil.copy2(root / 'prepared' / name, out / name)
for name in ['reporting-only.patch', 'selection-manifest.csv', 'check-kobe-evaluation.py']:
    shutil.copy2(package / name, out / name)
shutil.copy2(original_provenance, out / 'original-derivation-provenance.json')
p['created_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
p['original_template'] = str(source)
p['historical_provenance'] = 'original-derivation-provenance.json'
p['status'] = 'reproduction staged; compilation and evaluation pending'
p['compilation_command'] = args.admb + ' jjm2.tpl'
for key in ['compilation_exit_code', 'evaluation_exit_code', 'evaluation_wall_seconds',
            'evaluation_end_utc', 'native_output_sha256', 'native_output_bytes',
            'native_records', 'records_by_type', 'new_fields_verified_draw_years',
            'stock_f_ratio_check', 'canonical_files_rechecked', 'reference_grid_output_screen',
            'compilation_linked_library']:
    p.pop(key, None)
provenance_path = out / 'derivation-provenance.json'
provenance_path.write_text(json.dumps(p, indent=2) + '\n')
if args.stage_only:
    print('Staged and verified exact original inputs and 100 PSV records:', out)
    raise SystemExit(0)
help_result = subprocess.run([args.admb, '--help'], capture_output=True, text=True)
if 'Release Version: 13.2' not in help_result.stdout + help_result.stderr:
    raise SystemExit('ADMB 13.2 is required; pass --admb /absolute/path/to/admb-13.2/admb')
with (out / 'compile.log').open('w') as log:
    compile_result = subprocess.run([args.admb, 'jjm2.tpl'], cwd=out, stdout=log, stderr=subprocess.STDOUT)
p['compilation_exit_code'] = compile_result.returncode
provenance_path.write_text(json.dumps(p, indent=2) + '\n')
if compile_result.returncode:
    raise SystemExit('Compilation failed; see kobe-evaluation/compile.log')
start = time.monotonic()
command = ['./jjm2','-nox','-ind','h1_1.06.ctl','-mceval','-nohess','-fut_sel','3']
with (out / 'mceval.log').open('w') as log:
    evaluation = subprocess.run(command, cwd=out, stdout=log, stderr=subprocess.STDOUT)
p['evaluation_exit_code'] = evaluation.returncode
p['evaluation_wall_seconds'] = time.monotonic() - start
p['evaluation_end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
p['status'] = 'reproduction evaluation complete; verification pending'
provenance_path.write_text(json.dumps(p, indent=2) + '\n')
if evaluation.returncode:
    raise SystemExit('Evaluation failed; see kobe-evaluation/mceval.log')
subprocess.run([sys.executable, str(out / 'check-kobe-evaluation.py')], check=True)
print('Validated reporting-only native output:', out / 'mceval.rep')
