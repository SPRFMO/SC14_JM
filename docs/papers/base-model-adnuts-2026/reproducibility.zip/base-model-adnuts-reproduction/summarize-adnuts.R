#!/usr/bin/env Rscript
# Independent, post-run diagnostics. No model fitting or sampling is performed.
# Usage: Rscript --vanilla summarize-adnuts.R [fit.rds] [output-directory]
suppressPackageStartupMessages({
  library(posterior)
  library(ggplot2)
})

summarize_adnuts <- function(fit_path, output_dir = dirname(fit_path)) {
  stopifnot(file.exists(fit_path))
  fit <- readRDS(fit_path)
  samples <- fit$samples
  if (!is.array(samples) || length(dim(samples)) != 3L)
    stop("Expected fit$samples with iteration, chain, and variable dimensions.")
  dims <- dim(samples)
  warmup <- fit$warmup
  if (length(warmup) != 1L || !is.finite(warmup) || warmup < 0 ||
      warmup != floor(warmup) || warmup >= dims[1L])
    stop("Invalid saved warmup count; cannot identify retained iterations.")
  variable_names <- dimnames(samples)[[3L]]
  if (is.null(variable_names) || anyDuplicated(variable_names))
    stop("Unique variable names are required to report parameter diagnostics.")
  if (!"lp__" %in% variable_names)
    stop("Expected an explicitly named lp__ column in the adnuts draw array.")
  retained <- seq.int(warmup + 1L, dims[1L])
  post <- samples[retained, , , drop = FALSE]
  n_chains <- dims[2L]
  n_variables <- dims[3L]
  n_kept <- length(retained)
  is_parameter <- variable_names != "lp__"
  if (sum(is_parameter) == 0L) stop("No active parameters found.")
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

  # Check each chain explicitly: a finite pooled variance can conceal a stuck
  # chain, and posterior diagnostics are undefined for nonfinite draws.
  nonfinite <- vapply(seq_len(n_variables), function(j)
    sum(!is.finite(post[, , j])), numeric(1))
  stuck_matrix <- vapply(seq_len(n_variables), function(j) {
    vapply(seq_len(n_chains), function(ch) {
      z <- post[, ch, j]
      z <- z[is.finite(z)]
      length(z) > 0L && length(unique(z)) == 1L
    }, logical(1))
  }, logical(n_chains))
  if (n_chains == 1L) dim(stuck_matrix) <- c(1L, n_variables)
  stuck_chains <- colSums(stuck_matrix)
  summary_columns <- c("mean", "median", "sd", "q2.5", "q25", "q75",
                       "q97.5", "mcse_mean", "rhat", "ess_bulk", "ess_tail")
  parameter_summary <- data.frame(variable = variable_names,
    is_parameter = is_parameter, stringsAsFactors = FALSE)
  for (column in summary_columns) parameter_summary[[column]] <- NA_real_
  diagnostic_warnings <- character()
  finite_variables <- which(nonfinite == 0L)
  if (length(finite_variables)) {
    draw_array <- posterior::as_draws_array(post[, , finite_variables, drop = FALSE])
    finite_summary <- withCallingHandlers(
      posterior::summarise_draws(draw_array,
        mean = base::mean, median = stats::median, sd = stats::sd,
        quantiles = function(x) setNames(
          stats::quantile(x, probs = c(.025, .25, .75, .975), names = FALSE),
          c("q2.5", "q25", "q75", "q97.5")),
        mcse_mean = posterior::mcse_mean, rhat = posterior::rhat,
        ess_bulk = posterior::ess_bulk, ess_tail = posterior::ess_tail),
      warning = function(w) {
        diagnostic_warnings <<- c(diagnostic_warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      })
    row_index <- match(finite_summary$variable, parameter_summary$variable)
    parameter_summary[row_index, summary_columns] <-
      as.data.frame(finite_summary)[, summary_columns]
  }
  # Descriptive summaries of finite values remain available if a variable has
  # nonfinite draws; convergence diagnostics remain NA and the variable fails.
  for (j in which(nonfinite > 0L)) {
    z <- as.vector(post[, , j]); z <- z[is.finite(z)]
    if (length(z)) {
      parameter_summary[j, c("mean", "median", "sd", "q2.5", "q25",
                              "q75", "q97.5")] <- c(mean(z), median(z), sd(z),
        quantile(z, c(.025, .25, .75, .975), names = FALSE))
    }
  }
  parameter_summary$nonfinite_draws <- nonfinite
  parameter_summary$stuck_chains <- stuck_chains
  parameter_summary$rhat_above_1_01 <- with(parameter_summary,
    is.finite(rhat) & rhat > 1.01)
  parameter_summary$bulk_ess_below_400 <- with(parameter_summary,
    is.finite(ess_bulk) & ess_bulk < 400)
  parameter_summary$tail_ess_below_400 <- with(parameter_summary,
    is.finite(ess_tail) & ess_tail < 400)
  parameter_summary$diagnostics_nonfinite <- with(parameter_summary,
    !is.finite(rhat) | !is.finite(ess_bulk) | !is.finite(ess_tail) |
      !is.finite(mcse_mean))
  parameter_summary$passes_parameter_checks <- with(parameter_summary,
    nonfinite_draws == 0L & stuck_chains == 0L & !diagnostics_nonfinite &
      !rhat_above_1_01 & !bulk_ess_below_400 & !tail_ess_below_400)
  parameter_summary$diagnostic_status <- vapply(seq_len(n_variables), function(j) {
    x <- parameter_summary[j, ]
    flags <- c(if (x$nonfinite_draws > 0) "nonfinite draws",
      if (x$stuck_chains > 0) "constant draws in at least one chain",
      if (x$diagnostics_nonfinite) "undefined diagnostics",
      if (x$rhat_above_1_01) "Rhat > 1.01",
      if (x$bulk_ess_below_400) "bulk ESS < 400",
      if (x$tail_ess_below_400) "tail ESS < 400")
    if (length(flags)) paste(flags, collapse = "; ") else "passes screening"
  }, character(1))
  write.csv(parameter_summary, file.path(output_dir, "parameter-summary.csv"),
            row.names = FALSE, na = "NA")

  sp <- fit$sampler_params
  required_sp <- c("accept_stat__", "stepsize__", "treedepth__", "n_leapfrog__",
                   "divergent__", "energy__")
  if (!is.list(sp) || length(sp) != n_chains)
    stop("Sampler diagnostics must contain one element per saved chain.")
  max_depth <- as.numeric(fit$max_treedepth)
  if (length(max_depth) != 1L || !is.finite(max_depth))
    stop("Cannot evaluate tree-depth saturation without fit$max_treedepth.")
  finite_mean <- function(x) if (all(is.finite(x))) mean(x) else NA_real_
  chain_diagnostics <- do.call(rbind, lapply(seq_len(n_chains), function(ch) {
    z <- as.data.frame(sp[[ch]])
    if (nrow(z) != dims[1L] || !all(required_sp %in% names(z)))
      stop("Sampler rows/columns do not align with saved draw iterations.")
    z <- z[retained, required_sp, drop = FALSE]
    energy <- z$energy__
    ebfmi <- if (length(energy) > 1L && all(is.finite(energy)) &&
                 is.finite(var(energy)) && var(energy) > 0)
      mean(diff(energy)^2) / var(energy) else NA_real_
    divergences <- if (all(is.finite(z$divergent__)))
      sum(z$divergent__ != 0) else NA_integer_
    depth_hits <- if (all(is.finite(z$treedepth__)))
      sum(z$treedepth__ >= max_depth) else NA_integer_
    data.frame(chain = ch, warmup_draws = warmup, retained_draws = n_kept,
      divergent_transitions = divergences,
      divergent_fraction = divergences / n_kept,
      max_treedepth = max_depth, max_treedepth_hits = depth_hits,
      max_treedepth_fraction = depth_hits / n_kept,
      ebfmi = ebfmi, ebfmi_below_0_3 = is.finite(ebfmi) && ebfmi < .3,
      mean_accept_stat = finite_mean(z$accept_stat__),
      median_stepsize = if (all(is.finite(z$stepsize__))) median(z$stepsize__) else NA_real_,
      mean_leapfrog_steps = finite_mean(z$n_leapfrog__),
      nonfinite_sampler_values = sum(!is.finite(as.matrix(z))),
      nonfinite_parameter_draws = sum(!is.finite(post[, ch, is_parameter, drop = FALSE])),
      constant_parameters = sum(stuck_matrix[ch, is_parameter]),
      stringsAsFactors = FALSE)
  }))
  chain_diagnostics$passes_sampler_checks <- with(chain_diagnostics,
    nonfinite_sampler_values == 0L & is.finite(ebfmi) & ebfmi >= .3 &
      is.finite(divergent_transitions) & divergent_transitions == 0L &
      is.finite(max_treedepth_hits) & max_treedepth_hits == 0L)
  write.csv(chain_diagnostics, file.path(output_dir, "chain-diagnostics.csv"),
            row.names = FALSE, na = "NA")

  # Four slow/failed parameters, followed by a recruitment-scale parameter and
  # lp__. Chain separation is retained in both warmup traces and marginals.
  active_summary <- parameter_summary[is_parameter, ]
  sort_rhat <- ifelse(is.finite(active_summary$rhat), active_summary$rhat, Inf)
  sort_ess <- ifelse(is.finite(active_summary$ess_bulk), active_summary$ess_bulk, -Inf)
  ranking <- order(active_summary$passes_parameter_checks, -sort_rhat, sort_ess)
  worst <- head(active_summary$variable[ranking], 4L)
  recruitment_name <- grep("^log_Rzero($|\\[)|^mean_log_rec($|\\[)",
                           variable_names, value = TRUE)
  selection <- unique(c(worst, head(recruitment_name, 1L), "lp__"))
  if (length(selection) < min(6L, n_variables))
    selection <- unique(c(selection, head(setdiff(variable_names, selection),
                                        min(6L, n_variables) - length(selection))))
  selection <- head(selection, 6L)
  long_draws <- do.call(rbind, lapply(selection, function(v) {
    j <- match(v, variable_names)
    do.call(rbind, lapply(seq_len(n_chains), function(ch)
      data.frame(iteration = seq_len(dims[1L]), chain = factor(ch),
                 variable = v, value = samples[, ch, j])))
  }))
  long_draws$variable <- factor(long_draws$variable, levels = selection)
  chain_colors <- c("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")
  names(chain_colors) <- as.character(seq_along(chain_colors))
  chain_linetypes <- c("solid", "dashed", "dotdash", "longdash", "dotted", "twodash")
  names(chain_linetypes) <- as.character(seq_along(chain_linetypes))
  chart_theme <- theme_bw(base_size = 11) + theme(
    panel.grid.minor = element_blank(), legend.position = "bottom",
    strip.background = element_rect(fill = "#EDF1F3"),
    plot.title = element_text(face = "bold"))
  trace_plot <- ggplot(long_draws, aes(iteration, value, color = chain, linetype = chain)) +
    annotate("rect", xmin = .5, xmax = warmup + .5, ymin = -Inf, ymax = Inf,
             fill = "grey80", alpha = .4) +
    geom_line(linewidth = .25, alpha = .75, na.rm = TRUE) +
    geom_vline(xintercept = warmup + .5, linetype = 2, linewidth = .4) +
    facet_wrap(~variable, ncol = 2, scales = "free_y") +
    scale_color_manual(values = chain_colors, name = "Chain") +
    scale_linetype_manual(values = chain_linetypes, name = "Chain") +
    labs(title = "Base-model NUTS traces", x = "Saved iteration (warmup included)",
      y = "Parameter value / log posterior",
      subtitle = "Four slowest or failed parameter diagnostics, recruitment scale, and log posterior",
      caption = "Grey region: warmup excluded from every reported posterior diagnostic and interval.") +
    chart_theme
  ggsave(file.path(output_dir, "trace-selected.png"), trace_plot,
         width = 11, height = 9, dpi = 180, bg = "white")

  retained_long <- long_draws[long_draws$iteration > warmup &
                              is.finite(long_draws$value), ]
  retained_long$key <- interaction(retained_long$variable, retained_long$chain)
  group_values <- split(retained_long$value, retained_long$key, drop = TRUE)
  density_keys <- names(group_values)[vapply(group_values,
    function(x) length(x) > 1L && length(unique(x)) > 1L, logical(1))]
  density_data <- retained_long[retained_long$key %in% density_keys, ]
  constant_data <- unique(retained_long[!retained_long$key %in% density_keys,
                                       c("variable", "chain", "value")])
  marginal_plot <- ggplot() +
    geom_density(data = density_data,
      aes(value, color = chain, linetype = chain, group = interaction(variable, chain)),
      linewidth = .6, na.rm = TRUE, key_glyph = "path") +
    geom_vline(data = constant_data,
      aes(xintercept = value, color = chain, linetype = chain),
      linewidth = .6, show.legend = FALSE) +
    facet_wrap(~variable, ncol = 2, scales = "free") +
    scale_color_manual(values = chain_colors, name = "Chain") +
    scale_linetype_manual(values = chain_linetypes, name = "Chain") +
    labs(title = "Retained-draw marginal distributions", x = "Parameter value / log posterior",
      y = "Density", subtitle = "The same selected variables; each chain is shown separately",
      caption = "Vertical lines denote constant chains. Marginals do not establish convergence.") +
    chart_theme
  ggsave(file.path(output_dir, "marginals-selected.png"), marginal_plot,
         width = 11, height = 9, dpi = 180, bg = "white")

  finite_extreme <- function(x, fun) {
    x <- x[is.finite(x)]; if (length(x)) fun(x) else NA_real_
  }
  overall_pass <- all(active_summary$passes_parameter_checks) &&
    all(chain_diagnostics$passes_sampler_checks) &&
    parameter_summary$passes_parameter_checks[match("lp__", variable_names)]
  output_summary <- list(
    source_fit = normalizePath(fit_path), generated_at_utc = format(Sys.time(),
      "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    package_versions = as.list(sapply(c("adnuts", "posterior", "ggplot2", "jsonlite"),
      function(x) as.character(packageVersion(x)))),
    dimensions = list(saved_iterations_per_chain = dims[1L], chains = n_chains,
      warmup_per_chain = warmup, retained_per_chain = n_kept,
      retained_total = n_kept * n_chains, active_parameters = sum(is_parameter),
      variables_including_lp = n_variables),
    thresholds = list(maximum_rhat = 1.01, minimum_bulk_ess = 400,
      minimum_tail_ess = 400, minimum_ebfmi = .3, allowed_divergences = 0L,
      allowed_max_treedepth_hits = 0L),
    parameter_checks = list(denominator = sum(is_parameter),
      passing = sum(active_summary$passes_parameter_checks),
      failing_any = sum(!active_summary$passes_parameter_checks),
      rhat_above_1_01 = sum(active_summary$rhat_above_1_01),
      bulk_ess_below_400 = sum(active_summary$bulk_ess_below_400),
      tail_ess_below_400 = sum(active_summary$tail_ess_below_400),
      undefined_diagnostics = sum(active_summary$diagnostics_nonfinite),
      parameters_with_nonfinite_draws = sum(active_summary$nonfinite_draws > 0),
      parameters_constant_in_any_chain = sum(active_summary$stuck_chains > 0),
      maximum_finite_rhat = finite_extreme(active_summary$rhat, max),
      minimum_finite_bulk_ess = finite_extreme(active_summary$ess_bulk, min),
      minimum_finite_tail_ess = finite_extreme(active_summary$ess_tail, min)),
    sampler_checks = list(chains = n_chains,
      passing_chains = sum(chain_diagnostics$passes_sampler_checks),
      divergent_transitions = sum(chain_diagnostics$divergent_transitions),
      max_treedepth_hits = sum(chain_diagnostics$max_treedepth_hits),
      minimum_finite_ebfmi = finite_extreme(chain_diagnostics$ebfmi, min)),
    lp_diagnostics = as.list(parameter_summary[!is_parameter, ]),
    screening_status = if (overall_pass) "passes reported screening" else "fails reported screening",
    inference_note = if (overall_pass)
      "These checks assess finite-run sampling performance; they do not establish model validity or posterior convergence."
      else "Sampling diagnostics fail; retained-draw intervals and marginals are exploratory and should not be used for inference.",
    selected_plot_variables = selection,
    diagnostic_warnings = unique(diagnostic_warnings),
    notes = c("Active parameter counts exclude lp__; lp__ is assessed separately.",
      "Rhat is posterior's rank-normalized split Rhat; ESS is bulk/tail ESS across all retained chains.",
      "MCSE of the mean is computed using retained draws and preserved chain structure.",
      "E-BFMI is mean(diff(energy)^2)/var(energy) within each retained chain.",
      "All warmup counts refer to saved iterations, as represented by fit$warmup.",
      "Model parameters retain their native ADMB scales; no scientific derived quantities are inferred."))
  jsonlite::write_json(output_summary, file.path(output_dir, "diagnostic-summary.json"),
                       auto_unbox = TRUE, pretty = TRUE, na = "null", digits = NA)
  message(output_summary$screening_status, "; ",
    sum(active_summary$passes_parameter_checks), "/", sum(is_parameter),
    " active parameters pass all reported parameter checks.")
  invisible(output_summary)
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  script_arg <- grep("^--file=", commandArgs(), value = TRUE)
  script_dir <- if (length(script_arg)) dirname(normalizePath(sub("^--file=", "", script_arg[1L]))) else getwd()
  fit_path <- if (length(args)) args[1L] else file.path(script_dir, "fit.rds")
  output_dir <- if (length(args) > 1L) args[2L] else dirname(fit_path)
  summarize_adnuts(fit_path, output_dir)
}
