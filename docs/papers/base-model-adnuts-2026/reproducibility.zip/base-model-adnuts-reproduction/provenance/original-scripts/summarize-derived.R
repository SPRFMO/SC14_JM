#!/usr/bin/env Rscript
# Summarize the complete pooled, POST-WARMUP h1_1.06 -mceval output.
# Usage: Rscript summarize-derived.R [run_root] [mceval_file]
# The pooled PSV must contain chain 1, then 2, then 3, each with 1000 draws.
.libPaths(c('/Users/jim/Library/R/4.6/library', .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
})

read_report_block <- function(path, label) {
  txt <- readLines(path, warn = FALSE)
  begin <- which(trimws(txt) == paste0('$', label))
  if (length(begin) != 1L) stop('Expected one report block: ', label)
  following <- which(grepl('^\\$', trimws(txt)) & seq_along(txt) > begin)
  end <- if (length(following)) min(following) - 1L else length(txt)
  ans <- fread(text = paste(txt[seq.int(begin + 1L, end)], collapse = '\n'),
               header = FALSE, showProgress = FALSE)
  if (ncol(ans) != 5L) stop('Expected five columns in report block ', label)
  setnames(ans, c('year', 'mode', 'mode_sd', 'mode_lower_2se', 'mode_upper_2se'))
  ans
}

read_mceval_selected <- function(path, expected_draws) {
  con <- file(path, open = 'rt')
  on.exit(close(con))
  header <- trimws(readLines(con, n = 1L, warn = FALSE))
  # write_mceval_hdr omits the unit field, although every data row has six fields.
  if (!identical(header, 'mcdraw type Year Age value')) {
    stop('Unexpected mceval header; check active template before parsing: ', header)
  }
  retained <- list()
  inventory <- list()
  nlines <- 0L
  block <- 0L
  repeat {
    lines <- readLines(con, n = 200000L, warn = FALSE)
    if (!length(lines)) break
    block <- block + 1L
    part <- fread(text = paste(lines, collapse = '\n'), header = FALSE,
                  col.names = c('mcdraw', 'type', 'unit', 'year', 'age', 'value'),
                  colClasses = c('integer', 'character', 'integer', 'character',
                                 'character', 'numeric'),
                  showProgress = FALSE)
    if (ncol(part) != 6L || anyNA(part$mcdraw) || anyNA(part$unit) ||
        any(part$mcdraw < 1L | part$mcdraw > expected_draws)) {
      stop('Malformed or unexpected draw identifiers in mceval block ', block)
    }
    inventory[[block]] <- part[, .(
      records = .N, nonfinite = sum(!is.finite(value)),
      first_draw = min(mcdraw), last_draw = max(mcdraw)
    ), by = type]
    retained[[block]] <- part[type %chin% c('SSB', 'Recruits')]
    nlines <- nlines + nrow(part)
    if (block %% 25L == 0L) message('Read ', format(nlines, big.mark = ','), ' mceval records')
  }
  if (!block) stop('mceval file contains no draws')
  list(draws = rbindlist(retained),
       inventory = rbindlist(inventory)[, .(
         records = sum(records), nonfinite = sum(nonfinite),
         first_draw = min(first_draw), last_draw = max(last_draw)
       ), by = type], records = nlines)
}

summarize_values <- function(values, iterations, chains) {
  if (length(values) != iterations * chains) stop('Incomplete derived quantity')
  x <- matrix(values, nrow = iterations, ncol = chains)
  q <- quantile(values, probs = c(.025, .25, .5, .75, .975), names = FALSE)
  list(n = length(values), mean = mean(values), sd = sd(values),
       lower95 = q[1L], lower50 = q[2L], median = q[3L], upper50 = q[4L],
       upper95 = q[5L], rhat = posterior::rhat(x),
       ess_bulk = posterior::ess_bulk(x), ess_tail = posterior::ess_tail(x),
       mcse_mean = posterior::mcse_mean(x))
}

main <- function(args = commandArgs(trailingOnly = TRUE)) {
  root <- normalizePath(if (length(args)) args[1L] else
                          'output/base-model-mcmc-2026-09-10', mustWork = TRUE)
  path <- if (length(args) > 1L) args[2L] else file.path(root, 'run', 'mceval.rep')
  if (!file.exists(path)) stop('Missing pooled -mceval output: ', path)
  manifest <- jsonlite::read_json(file.path(root, 'run-manifest.json'), simplifyVector = TRUE)
  chains <- as.integer(manifest$chains)
  iterations <- as.integer((manifest$iterations_per_chain - manifest$warmup_per_chain) /
                             manifest$thin)
  # This workflow is intentionally locked to the requested package-default run.
  stopifnot(chains == 3L, iterations == 1000L, manifest$model == 'h1_1.06')
  expected <- chains * iterations
  read <- read_mceval_selected(path, expected)
  expected_records_per_draw <- c(
    MSY = 1L, SBMSY = 1L, FMSY = 1L, R0 = 1L, B0 = 1L,
    SSB = 57L, Fbar = 57L, Recruits = 57L, Deviances = 57L,
    SBMSYy = 57L, N_stock = 684L, Depletion = 1L, Dynamic_Depletion = 1L,
    Sel_fsh = 2736L, C_fsh = 2736L, F_faa = 2736L, F_fsh = 228L,
    Q_ind = 126L, Pred_ind = 126L, Sel_ind = 4104L)
  if (!setequal(read$inventory$type, names(expected_records_per_draw)) ||
      any(read$inventory$records != expected *
            expected_records_per_draw[read$inventory$type]) ||
      any(read$inventory$first_draw != 1L | read$inventory$last_draw != expected)) {
    stop('Raw mceval inventory is incomplete or differs from the frozen base-model schema')
  }
  d <- read$draws
  if (!setequal(unique(d$mcdraw), seq_len(expected))) stop('Expected exactly 3000 pooled draws')
  if (!identical(sort(unique(d$unit)), 1L)) stop('This report expects the one-stock base model')
  d[, year := as.integer(year)]
  if (anyNA(d$year) || any(!is.finite(d$value))) stop('Nonfinite selected derived values')
  if (any(d$value < 0)) stop('Unexpected negative selected derived values')
  if (nrow(unique(d, by = c('mcdraw', 'type', 'unit', 'year', 'age'))) != nrow(d)) {
    stop('Duplicated derived quantity for a draw')
  }
  stopifnot(identical(sort(unique(d[type == 'SSB', year])), 1970:2026),
            identical(sort(unique(d[type == 'Recruits', year])), 1970:2026),
            identical(unique(d[type == 'Recruits', age]), 'age_1'))
  counts <- d[, .(n_draws = uniqueN(mcdraw)), by = .(type, unit, year, age)]
  if (any(counts$n_draws != expected)) stop('Incomplete draw coverage for selected quantity')
  d[, `:=`(chain = (mcdraw - 1L) %/% iterations + 1L,
            iteration = (mcdraw - 1L) %% iterations + 1L)]
  setorder(d, type, unit, year, age, mcdraw)
  summary <- d[, summarize_values(value, iterations, chains), by = .(type, unit, year, age)]
  labels <- c(SSB = 'Spawning biomass', Recruits = 'Recruitment at age 1')
  summary[, `:=`(quantity = unname(labels[type]),
                 units = fifelse(type == 'SSB', 'thousand tonnes (kt)',
                           fifelse(type == 'Recruits', 'million fish', 'ratio')))]

  # Prepared reports were regenerated at the original saved parameter vector.
  # Check objective equality again before using them as mode comparators.
  objective <- function(file) {
    h <- readLines(file, n = 1L, warn = FALSE)
    as.numeric(sub('.*Objective function value = ([^ ]+).*', '\\1', h))
  }
  stopifnot(abs(objective(file.path(root, 'source', 'h1_1.06.par')) -
                  objective(file.path(root, 'prepared', 'jjm2.par'))) < 1e-6)
  repfile <- file.path(root, 'prepared', 'For_R_1.rep')
  ssb_mode <- read_report_block(repfile, 'SSB')[year %in% 1970:2026]
  rec_mode <- read_report_block(repfile, 'R')[year %in% 1970:2026]
  ssb_mode[, type := 'SSB']
  rec_mode[, type := 'Recruits']
  modes <- rbindlist(list(ssb_mode, rec_mode))
  summary <- merge(summary, modes, by = c('type', 'year'), all.x = TRUE, sort = FALSE)
  summary[, median_minus_mode_percent := 100 * (median / mode - 1)]
  summary[, diagnostic_flag := !is.finite(rhat) | rhat > 1.01 |
            !is.finite(ess_bulk) | ess_bulk < 400 |
            !is.finite(ess_tail) | ess_tail < 400]
  setorder(summary, type, year)
  terminal <- summary[year == 2026L]
  out <- file.path(root, 'derived')
  dir.create(out, showWarnings = FALSE)
  fwrite(read$inventory[order(type)], file.path(out, 'mceval-inventory.csv'))
  fwrite(summary, file.path(out, 'derived-summary.csv'))
  fwrite(terminal, file.path(out, 'terminal-2026-summary.csv'))
  fwrite(d[year == 2026L], file.path(out, 'terminal-2026-draws.csv.gz'))
  fwrite(modes, file.path(out, 'original-mode-comparison.csv'))
  saveRDS(d[type %chin% c('SSB', 'Recruits')], file.path(out, 'trajectory-draws.rds'))
  gate <- list(
    selected_quantities_pass_rhat_ess_screen = !any(summary$diagnostic_flag),
    flagged_quantity_years = sum(summary$diagnostic_flag),
    assessed_quantity_years = nrow(summary),
    max_rhat = max(summary$rhat), min_ess_bulk = min(summary$ess_bulk),
    min_ess_tail = min(summary$ess_tail),
    thresholds = list(rhat_max = 1.01, ess_bulk_min = 400, ess_tail_min = 400),
    scope = 'Derived quantity screen only. Parameter, divergence, tree-depth and energy diagnostics must also be checked.',
    interval = 'Empirical equal-tail 2.5th to 97.5th percentiles of retained draws. Interpret as posterior credible intervals only after full-run convergence review.',
    chain_order = 'Pooled PSV order: chain 1, then chain 2, then chain 3; 1000 retained draws each.',
    records_read = read$records, draw_count = expected,
    mode_comparator = 'prepared/For_R_1.rep regenerated at original saved parameters; objective checked against source/h1_1.06.par',
    mode_interval = 'Original report limits are exp(+/-2*sqrt(log(1+CV^2))) about the mode. They are a lognormal approximation using 2 SE, not the same construction as MCMC equal-tail 95% intervals.',
    biological_units = list(SSB = 'thousand tonnes', Recruits = 'million fish at age 1'),
    quantity_definitions = as.list(labels),
    mceval_file = normalizePath(path), generated_at = format(Sys.time(), '%Y-%m-%dT%H:%M:%S%z')
  )
  jsonlite::write_json(gate, file.path(out, 'derived-status.json'), pretty = TRUE,
                       auto_unbox = TRUE, na = 'null')

  # Captions retain a diagnostic interpretation regardless of the selected screen;
  # all-parameter convergence is assessed separately by the main run workflow.
  theme_set(theme_minimal(base_size = 12) +
              theme(panel.grid.minor = element_blank(), legend.position = 'bottom',
                    plot.title.position = 'plot'))
  for (kind in c('SSB', 'Recruits')) {
    sdf <- summary[type == kind]
    ylab <- if (kind == 'SSB') 'Spawning biomass (thousand tonnes)' else
      'Recruitment at age 1 (million fish)'
    p <- ggplot(sdf, aes(year, median)) +
      geom_ribbon(aes(ymin = lower95, ymax = upper95), fill = '#2878A4', alpha = .17) +
      geom_ribbon(aes(ymin = lower50, ymax = upper50), fill = '#2878A4', alpha = .22) +
      geom_line(aes(colour = 'Retained-sample median'), linewidth = .7) +
      geom_line(aes(y = mode, colour = 'Original fitted mode'), linewidth = .7,
                linetype = 'dashed') +
      scale_colour_manual(values = c('Retained-sample median' = '#1D648C',
                                     'Original fitted mode' = '#A14419'), name = NULL) +
      labs(x = 'Year', y = ylab, title = unname(labels[kind]),
           subtitle = 'Default ADNUTS run: retained-sample summary',
           caption = 'Shading: central 50% and 95% sample intervals.\nPosterior interpretation requires satisfactory full-run convergence diagnostics.')
    filename <- if (kind == 'SSB') 'ssb-trajectory.png' else 'recruitment-trajectory.png'
    ggsave(file.path(out, filename), p, width = 9.6, height = 5.6, dpi = 180)
  }
  td <- d[type == 'SSB' & year == 2026L]
  td[, chain := factor(chain)]
  mode_ssb <- terminal[type == 'SSB', mode]
  chain_palette <- c('#166C9C', '#B95B25', '#25835B')
  trace <- ggplot(td, aes(iteration, value, colour = chain, linetype = chain)) +
    geom_line(linewidth = .35, alpha = .8) +
    geom_hline(yintercept = mode_ssb, linetype = 'dashed', colour = '#333333') +
    scale_colour_manual(values = chain_palette, name = 'Chain') +
    scale_linetype_manual(values = c('solid', 'dotted', 'dotdash'), name = 'Chain') +
    labs(x = 'Retained iteration (after 1000 warmup iterations)',
         y = '2026 spawning biomass (thousand tonnes)',
         title = '2026 spawning biomass: chain traces',
         caption = 'Dashed line: original fitted mode. Chain order restored from pooled PSV order.')
  ggsave(file.path(out, 'terminal-ssb-trace.png'), trace, width = 9.6, height = 5.2, dpi = 180)
  density <- ggplot(td, aes(value, colour = chain, fill = chain, linetype = chain)) +
    geom_density(alpha = .08, linewidth = .7) +
    geom_vline(xintercept = mode_ssb, linetype = 'dashed', colour = '#333333') +
    scale_colour_manual(values = chain_palette, name = 'Chain') +
    scale_linetype_manual(values = c('solid', 'dotted', 'dotdash'), name = 'Chain') +
    scale_fill_manual(values = chain_palette, name = 'Chain') +
    labs(x = '2026 spawning biomass (thousand tonnes)', y = 'Density',
         title = '2026 spawning biomass: retained draws by chain',
         caption = 'Dashed line: original fitted mode. Density estimates are diagnostic when chains have not converged.')
  ggsave(file.path(out, 'terminal-ssb-density.png'), density, width = 8.2, height = 5.2, dpi = 180)
  print(terminal[, .(quantity, units, mode, median, lower95, upper95, rhat,
                      ess_bulk, ess_tail, diagnostic_flag)])
  message('Derived summaries and diagnostic plots written to ', out)
  invisible(list(summary = summary, terminal = terminal, status = gate))
}

if (sys.nframe() == 0L) main()
