#!/bin/sh
# Evaluate the pooled post-warmup PSV without altering the sampling directory.
set -eu
if [ "$#" -ne 1 ]; then
  echo "Usage: sh evaluate.sh /absolute/reproduction/root" >&2
  exit 2
fi
root=$(cd "$1" && pwd)
if [ ! -s "$root/fit.rds" ] || [ ! -s "$root/run/jjm2.psv" ]; then
  echo "Complete the R sampling driver before evaluation." >&2
  exit 2
fi
if [ -e "$root/evaluation" ]; then
  echo "Refusing to overwrite existing evaluation/." >&2
  exit 2
fi
mkdir "$root/evaluation"
for file in jjm2 jjm2.dat h1_1.06.ctl 1.06.dat jjm2.bar jjm2.par; do
  cp "$root/prepared/$file" "$root/evaluation/$file"
done
cp "$root/run/jjm2.psv" "$root/evaluation/jjm2.psv"
cd "$root/evaluation"
./jjm2 -nox -ind h1_1.06.ctl -mceval -nohess -fut_sel 3 > mceval.log 2>&1
test -s mceval.rep
echo "Pooled post-warmup evaluation complete; run summarize-derived.R next."
