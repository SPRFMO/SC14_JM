#!/bin/sh
# Compile and regenerate Hessian/reports at the archived fitted parameter vector.
set -eu
if [ "$#" -ne 1 ]; then
  echo "Usage: ADMB=/absolute/path/to/admb-13.2/admb sh prepare.sh /absolute/reproduction/root" >&2
  exit 2
fi
root=$(cd "$1" && pwd)
admb_command=${ADMB:-admb}
if ! "$admb_command" --help 2>&1 | grep -Eq 'Release Version: 13[.]2([[:space:]]|$)'; then
  echo "ADMB 13.2 required; set ADMB to the absolute path of its admb command." >&2
  exit 2
fi
if [ -e "$root/build" ] || [ -e "$root/prepared" ]; then
  echo "Refusing to overwrite existing build/ or prepared/. Use a fresh extraction." >&2
  exit 2
fi
mkdir "$root/build" "$root/prepared"
cp "$root/source/jjm2.tpl" "$root/build/jjm2.tpl"
cd "$root/build"
# Default ADMB compilation links safe libraries; do not add -f.
"$admb_command" jjm2.tpl > compile.log 2>&1
cp jjm2 "$root/prepared/jjm2"
cp "$root/source/1.06.dat" "$root/prepared/1.06.dat"
cp "$root/source/h1_1.06.ctl" "$root/prepared/h1_1.06.ctl"
cp "$root/source/h1_1.06.ctl" "$root/prepared/jjm2.dat"
cp "$root/source/h1_1.06.par" "$root/prepared/h1_1.06.par"
cd "$root/prepared"
./jjm2 -nox -ind h1_1.06.ctl -ainp h1_1.06.par -phase 1000 -maxfn 0 -hbf -fut_sel 3 > prepare.log 2>&1
for required in jjm2 jjm2.dat h1_1.06.ctl 1.06.dat admodel.hes jjm2.par jjm2.cor jjm2.bar For_R_1.rep; do
  if [ ! -s "$required" ]; then
    echo "Preparation did not create required nonempty file: $required" >&2
    exit 1
  fi
done
echo "Preparation complete. Run the R driver with the explicit reproduction root."
