#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(adnuts))
if (as.character(packageVersion('adnuts')) != '1.1.2')
  stop('This reproduction requires adnuts 1.1.2 so its defaults match the archived run.')
args <- commandArgs(trailingOnly = TRUE)
root <- normalizePath(if (length(args)) args[[1]] else 'output/base-model-mcmc-2026-09-10', mustWork = TRUE)
prepared <- file.path(root, 'prepared')
run <- file.path(root, 'run')
if (dir.exists(run)) stop('Refusing to overwrite an existing run: ', run)
required <- c('jjm2', 'jjm2.dat', 'h1_1.06.ctl', '1.06.dat', 'admodel.hes', 'jjm2.par', 'jjm2.cor')
stopifnot(all(file.exists(file.path(prepared, required))))
original_header <- readLines(file.path(root, 'source', 'h1_1.06.par'), n = 1)
prepared_header <- readLines(file.path(prepared, 'jjm2.par'), n = 1)
nll <- function(x) as.numeric(sub('.*Objective function value = ([^ ]+).*', '\\1', x))
stopifnot(abs(nll(original_header) - nll(prepared_header)) < 1e-6)
dir.create(run)
files <- list.files(prepared, full.names = TRUE)
stopifnot(all(file.copy(files, run)))
Sys.chmod(file.path(run, 'jjm2'), '0755')
set.seed(20260910)
rng_state <- .Random.seed
seed_preview <- sample.int(1e7, 3)
.Random.seed <- rng_state
defaults <- lapply(formals(adnuts::sample_nuts), function(x) paste(deparse(x), collapse = ' '))
settings <- list(
  model = 'h1_1.06', engine = 'ADMB', package = 'adnuts',
  version = as.character(packageVersion('adnuts')),
  requested_backend = 'SparseNUTS', approved_backend = 'adnuts',
  user_approved_backend_change = TRUE,
  iterations_per_chain = 2000, warmup_per_chain = 1000, chains = 3,
  expected_retained_draws = 3000, thin = 1,
  package_function = 'adnuts::sample_nuts', formal_defaults = defaults,
  resolved_control_defaults = adnuts:::.update_control(NULL),
  detected_cores = parallel::detectCores(), requested_cores = NULL,
  root_seed = 20260910, package_generated_chain_seeds = seed_preview,
  original_objective = nll(original_header), prepared_objective = nll(prepared_header),
  original_parameter_header = original_header, prepared_parameter_header = prepared_header,
  initialization = 'Package default NULL: same saved MPD in all chains',
  model_arguments = '-ind h1_1.06.ctl -fut_sel 3',
  preparation = './jjm2 -nox -ind h1_1.06.ctl -ainp h1_1.06.par -phase 1000 -maxfn 0 -hbf -fut_sel 3',
  preparation_gradient_note = 'The maxfn=0 header does not measure the gradient; use the original fitted header.',
  status = 'running', start_time = format(Sys.time(), '%Y-%m-%dT%H:%M:%S%z')
)
write_settings <- function() jsonlite::write_json(settings, file.path(root, 'run-manifest.json'), auto_unbox = TRUE, pretty = TRUE, null = 'null')
write_settings()
writeLines(capture.output(sessionInfo()), file.path(root, 'session-info.txt'))
cat('Model objective verified; starting adnuts::sample_nuts with package defaults.\n')
cat('Detected cores:', parallel::detectCores(), '; chain seeds:', seed_preview, '\n')
started <- Sys.time()
fit <- tryCatch(
  adnuts::sample_nuts(model = 'jjm2', path = run, admb_args = settings$model_arguments),
  error = function(e) {
    settings$status <<- 'failed'
    settings$error <<- conditionMessage(e)
    settings$end_time <<- format(Sys.time(), '%Y-%m-%dT%H:%M:%S%z')
    write_settings()
    stop(e)
  }
)
saveRDS(fit, file.path(root, 'fit.rds'))
settings$status <- 'sampling complete; diagnostics pending'
settings$end_time <- format(Sys.time(), '%Y-%m-%dT%H:%M:%S%z')
settings$wall_seconds <- as.numeric(difftime(Sys.time(), started, units = 'secs'))
settings$actual_dimensions <- dim(fit$samples)
settings$actual_warmup <- fit$warmup
settings$actual_commands <- fit$cmd
write_settings()
cat('\nSaved fit.rds; sampling complete.\n')
