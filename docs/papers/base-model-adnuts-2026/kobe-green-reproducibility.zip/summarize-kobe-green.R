#!/usr/bin/env Rscript
.libPaths(c('/Users/jim/Library/R/4.6/library', .libPaths()))
suppressPackageStartupMessages({library(data.table); library(ggplot2); library(posterior); library(jsonlite)})
args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(if(length(args)) args[1] else 'output/base-model-mcmc-2026-09-10')
out <- file.path(root,'kobe-green')
x <- fread(file.path(out,'kobe-all-draws-2007-2026.csv'))
stopifnot(nrow(x)==60000L, uniqueN(x$pooled_draw)==3000L,
          identical(sort(unique(x$year)),2007:2026),
          all(x[, .N, by=.(pooled_draw)]$N==20L),
          all(x[, .N, by=.(chain,year)]$N==1000L),
          all(x$green==as.integer(x$ssb_over_ssbmsy>1 & x$f_over_fmsy<1)),
          all(is.finite(x$ssb_over_ssbmsy)), all(is.finite(x$f_over_fmsy)))

# Independent cross-check against the previously published 100 matched draws.
old <- fread(file.path(root,'kobe','kobe-trajectories-100-draws-2007-2026.csv'))
check <- merge(old[,.(pooled_draw,year,old_b=ssb_over_ssbmsy,old_f=f_over_fmsy)],
               x[,.(pooled_draw,year,ssb_over_ssbmsy,f_over_fmsy)],by=c('pooled_draw','year'))
stopifnot(nrow(check)==2000L,
          max(abs(check$old_b-check$ssb_over_ssbmsy))<1e-12,
          max(abs(check$old_f-check$f_over_fmsy))<1e-12)

by_chain <- x[,.(green_draws=sum(green),retained_draws=.N,probability_green=mean(green)),by=.(year,chain)]
setorder(by_chain,year,chain)
summary <- rbindlist(lapply(2007:2026,function(yr){
  z <- x[year==yr][order(chain,retained_iteration)]
  m <- matrix(z$green,nrow=1000,ncol=3)
  varies <- length(unique(as.vector(m)))>1L
  finite_or_na <- function(v) if(length(v)==1 && is.finite(v)) as.numeric(v) else NA_real_
  rh <- if(varies) finite_or_na(posterior::rhat(m)) else NA_real_
  ess <- if(varies) finite_or_na(posterior::ess_mean(m)) else NA_real_
  mcse <- if(varies) finite_or_na(posterior::mcse_mean(m)) else NA_real_
  data.table(year=yr,green_draws=sum(m),retained_draws=length(m),
      probability_green=mean(m),chain1_probability=mean(m[,1]),
      chain2_probability=mean(m[,2]),chain3_probability=mean(m[,3]),
      indicator_rhat=rh,indicator_ess_mean=ess,probability_mcse=mcse,
      indicator_varies=varies)
}))
stopifnot(all(summary$probability_green==summary$green_draws/3000),
          max(abs(summary$probability_green-rowMeans(as.matrix(summary[,.(chain1_probability,chain2_probability,chain3_probability)]))))<1e-14)
fwrite(summary,file.path(out,'kobe-green-probability-2007-2026.csv'),na='NA')
fwrite(by_chain,file.path(out,'kobe-green-by-chain-2007-2026.csv'))
draw_file <- file.path(out,'kobe-green-draws-2007-2026.csv.gz')
fwrite(x,draw_file,compress='gzip')

p <- ggplot()+
  geom_line(data=by_chain,aes(year,probability_green*100,colour=factor(chain),linetype=factor(chain)),linewidth=.65,alpha=.85)+
  geom_line(data=summary,aes(year,probability_green*100),colour='#14623d',linewidth=1.2)+
  geom_point(data=summary,aes(year,probability_green*100),colour='#14623d',size=1.8)+
  scale_colour_manual(name='Chain',values=c('1'='#4477aa','2'='#cc6677','3'='#888888'))+
  scale_linetype_manual(name='Chain',values=c('1'='dashed','2'='dotted','3'='dotdash'))+
  scale_x_continuous(breaks=c(2007,2010,2015,2020,2026),minor_breaks=NULL)+
  scale_y_continuous(limits=c(0,100),breaks=seq(0,100,20),labels=function(z)paste0(z,'%'),expand=expansion(mult=c(.015,.025)))+
  labs(title='Posterior probability of Kobe green through time',
       subtitle='SSB / SSBMSY > 1 and F / FMSY < 1 | 2007–2026',
       x='Year',y='Estimated posterior probability',
       caption=paste('Thick green line and points: all 3,000 retained draws. Thin patterned lines: 1,000 draws per chain.',
       'SSBMSY: each draw’s mean for 2017–2026. FMSY: annual reference.',
       'Exploratory posterior estimates; further sampling is needed to improve chain agreement.',sep='\n'))+
  theme_minimal(base_size=12)+theme(legend.position='bottom',plot.caption=element_text(hjust=0,size=10),
       panel.grid.minor=element_blank(),plot.margin=margin(12,16,12,12))
ggsave(file.path(out,'kobe-green-probability-2007-2026.png'),p,width=10,height=6.4,dpi=220)
ggsave(file.path(out,'kobe-green-probability-2007-2026.svg'),p,width=10,height=6.4,device=svglite::svglite)

status <- list(status='complete; calculations and identity checks passed',
  model='h1_1.06',retained_draws=3000,chains=3,draws_per_chain=1000,years=2007:2026,
  definition='Kobe green: SSB / mean(annual SSBMSY, 2017–2026) > 1 AND mean-age summed fleet F / annual FMSY < 1.',
  boundary_rule='Strict inequalities; equality at either boundary falls outside the green quadrant.',
  probability_estimator='Number of retained draws in green in each year divided by 3000, equally weighting the three chains.',
  mcmc_uncertainty='MCSE uses the chain-preserving binary event indicator and posterior::mcse_mean; ESS uses posterior::ess_mean. Constant indicators have NA diagnostic entries.',
  zero_counts='A zero count records the observed retained draws; the estimate remains conditional on finite MCMC exploration.',
  interpretation='Exploratory posterior probabilities conditional on the base model; further sampling is needed to improve full-model chain agreement.',
  previous_100_draw_check=list(rows=nrow(check),max_b_difference=max(abs(check$old_b-check$ssb_over_ssbmsy)),max_f_difference=max(abs(check$old_f-check$f_over_fmsy))),
  terminal=as.list(summary[year==2026]),packages=list(R=R.version.string,posterior=as.character(packageVersion('posterior'))))
write_json(status,file.path(out,'kobe-green-status.json'),pretty=TRUE,auto_unbox=TRUE,digits=17,na='null')
print(summary)
