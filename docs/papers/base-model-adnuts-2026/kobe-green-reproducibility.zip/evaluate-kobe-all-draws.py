"""Stream the existing reporting-only ADMB evaluator into compact Kobe data.

Run from the archived base-model directory, with its original run/, source/,
prepared/ and validated kobe-evaluation/ inputs available. Uses a POSIX FIFO
to retain annual coordinates while hashing and checking the complete stream.
"""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, math, os, shutil, subprocess, threading, time

root = Path(__file__).resolve().parent
dest = root / 'kobe-all-draws-evaluation'
dest.mkdir(exist_ok=True)
out = root / 'kobe-green'
out.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prov = json.loads((root/'kobe-evaluation/derivation-provenance.json').read_text())
assert sha(root/'source/jjm2.tpl') == prov['original_template_sha256']
assert sha(root/'kobe-evaluation/jjm2.tpl') == prov['reporting_template_sha256']
assert sha(root/'run/jjm2.psv') == prov['pooled_psv_sha256']
for name in ['jjm2','jjm2.tpl','jjm2.dat','h1_1.06.ctl','1.06.dat','jjm2.bar','jjm2.par']:
    shutil.copy2(root/'kobe-evaluation'/name, dest/name)
shutil.copy2(root/'run/jjm2.psv',dest/'jjm2.psv')
for name, digest in prov['input_sha256'].items():
    assert sha(dest/name) == digest

fifo = dest/'mceval.rep'
if fifo.exists():
    # This directory belongs to this supplemental evaluation only.
    previous = json.loads((dest/'evaluation-status.json').read_text())
    assert previous['exit_code'] != 0, 'Preserve completed output'
    fifo.unlink()
os.mkfifo(fifo)
stats = {'records':0, 'stream_bytes':0, 'completed_draws':0,
         'maximum_f_ratio_relative_error':0, 'near_boundary_coordinates':0}
counts, failures = Counter(), []
stream_hash = hashlib.sha256()

def consume():
    try:
        with fifo.open('rb') as src, (out/'kobe-all-draws-2007-2026.csv').open('w') as target:
            writer = csv.writer(target)
            writer.writerow(['pooled_draw','chain','retained_iteration','year','ssb_kt',
                'ssbmsy_year_kt','ssbmsy_reference_kt','f_mean_all_ages_per_year',
                'fmsy_year_per_year','ssb_over_ssbmsy','f_over_fmsy','green'])
            header = src.readline()
            assert header.strip() == b'mcdraw type Year Age value'
            stream_hash.update(header); stats['stream_bytes'] += len(header)
            current, values, fleet_f, draw_records = 0, {}, {}, 0
            def finish(draw):
                assert draw_records == 13882, (draw,draw_records)
                assert len(values) == 80 and len(fleet_f) == 20
                b_ref = sum(values[y,'SBMSYy'] for y in range(2017,2027))/10
                assert b_ref > 0
                for year in range(2007,2027):
                    b, by, fy, native = [values[year,k] for k in ('SSB','SBMSYy','FMSYy','FFMSYy')]
                    assert b > 0 and by > 0 and 0.0001 < fy < 5
                    fvals = fleet_f[year]
                    assert len(fvals)==48 and set(fvals)=={(f,a) for f in range(1,5) for a in range(1,13)}
                    f = sum(fvals.values())/12
                    x,y = b/b_ref, f/fy
                    err=abs(y-native)/max(abs(y),abs(native),1e-30)
                    assert err < 2e-5, (draw,year,err)
                    stats['maximum_f_ratio_relative_error']=max(stats['maximum_f_ratio_relative_error'],err)
                    stats['near_boundary_coordinates'] += int(abs(x-1)<2e-5 or abs(y-1)<2e-5)
                    writer.writerow([draw,(draw-1)//1000+1,(draw-1)%1000+1,year,b,by,b_ref,f,fy,x,y,int(x>1 and y<1)])
                stats['completed_draws'] += 1
            for raw in src:
                stream_hash.update(raw); stats['stream_bytes'] += len(raw)
                bits=raw.split(); assert len(bits)==6
                draw=int(bits[0]); kind=bits[1].decode()
                if draw != current:
                    if current: finish(current)
                    assert draw == current+1
                    current,values,fleet_f,draw_records=draw,{},{},0
                stats['records']+=1; counts[kind]+=1; draw_records+=1
                if kind not in ('SSB','SBMSYy','FMSYy','FFMSYy','F_faa'):
                    continue
                year=int(bits[3])
                if 2007 <= year <= 2026:
                    if kind in ('SSB','SBMSYy','FMSYy','FFMSYy'):
                        assert bits[2]==b'1' and bits[4]==b'all'
                        key=year,kind; assert key not in values
                        values[key]=float(bits[5]); assert math.isfinite(values[key])
                    elif kind=='F_faa':
                        key=int(bits[2]),int(bits[4])
                        fv=fleet_f.setdefault(year,{})
                        assert key not in fv
                        fv[key]=float(bits[5]); assert math.isfinite(fv[key])
            finish(current)
            assert current==3000
    except BaseException as exc:
        failures.append(repr(exc))

reader=threading.Thread(target=consume,daemon=True); reader.start()
cmd=['./jjm2','-nox','-ind','h1_1.06.ctl','-mceval','-nohess','-fut_sel','3']
start=time.time()
with (dest/'evaluation.log').open('w') as log:
    result=subprocess.run(cmd,cwd=dest,stdout=log,stderr=subprocess.STDOUT)
reader.join(timeout=30)
assert not reader.is_alive()
fifo.unlink()
meta={'command':cmd,'exit_code':result.returncode,'wall_seconds':time.time()-start,
      'source':'validated two-line reporting-only evaluator, applied to all original retained draws',
      'original_template_sha256':prov['original_template_sha256'],
      'reporting_template_sha256':prov['reporting_template_sha256'],
      'executable_sha256':sha(dest/'jjm2'),'pooled_psv_sha256':sha(dest/'jjm2.psv'),
      'stream_sha256':stream_hash.hexdigest(),'stream_retention':'Compact annual quantities retained; full native stream hashed in transit',
      'statistics':stats,'records_by_type':dict(counts),'reader_errors':failures}
(dest/'evaluation-status.json').write_text(json.dumps(meta,indent=2)+'\n')
assert result.returncode==0 and not failures,meta
assert stats['completed_draws']==3000 and stats['records']==3000*13882
# Six significant digits bound relative rounding by 5e-6 for each positive
# native quantity, and hence for their positive weighted means and sums.
# Check that joint-event membership is stable over the resulting ratio bounds.
ambiguous=0
with (out/'kobe-all-draws-2007-2026.csv').open() as source:
    for row in csv.DictReader(source):
        x,y=float(row['ssb_over_ssbmsy']),float(row['f_over_fmsy'])
        low=(1-5e-6)/(1+5e-6); high=1/low
        definitely_green=x*low>1 and y*high<1
        possibly_green=x*high>1 and y*low<1
        ambiguous += definitely_green != possibly_green
meta['rounding_boundary_check']={'native_relative_rounding_bound':5e-6,
    'ambiguous_joint_classifications':ambiguous,
    'definition':'Worst-case ratio intervals from positive native six-significant-digit quantities, sums and means.'}
assert ambiguous==0, 'Resolve output rounding at the joint green boundary'
(dest/'evaluation-status.json').write_text(json.dumps(meta,indent=2)+'\n')
shutil.copy2(dest/'evaluation-status.json',out/'green-evaluation-status.json')
print(json.dumps(meta,indent=2))
